package ru.duo.aura.modules;

import net.minecraft.client.gui.screen.DeathScreen;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/** Мгновенное возрождение после смерти. */
public class AutoRespawn extends Module {

    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 5, 0, 60, 1));

    private int timer;

    public AutoRespawn() {
        super("AutoRespawn", "Сразу возрождает после смерти", Category.OPTIMIZER, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (!(mc.currentScreen instanceof DeathScreen)) { timer = 0; return; }
        if (timer++ < delay.asInt()) return;
        timer = 0;
        mc.player.requestRespawn();
        mc.setScreen(null);
    }
}
