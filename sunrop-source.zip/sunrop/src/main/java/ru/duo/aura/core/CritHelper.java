package ru.duo.aura.core;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffects;

/**
 * Ванильные условия крита: падение вниз, не на земле, не в воде/лаве,
 * не на лестнице, не в транспорте, не на элитрах,
 * нет левитации / медленного падения / слепоты, и НЕ спринт.
 */
public class CritHelper {

    public static boolean canCrit(ClientPlayerEntity p) {
        if (p.isOnGround()) return false;
        if (!(p.fallDistance > 0.0)) return false;
        if (p.getVelocity().y >= 0.0) return false;
        if (p.isClimbing()) return false;
        if (p.isTouchingWater() || p.isInLava()) return false;
        if (p.hasVehicle()) return false;
        if (p.isGliding()) return false;
        if (p.hasStatusEffect(StatusEffects.LEVITATION)) return false;
        if (p.hasStatusEffect(StatusEffects.SLOW_FALLING)) return false;
        if (p.hasStatusEffect(StatusEffects.BLINDNESS)) return false;
        return !p.isSprinting();
    }

    public static boolean canJump(ClientPlayerEntity p) {
        return p.isOnGround() && !p.hasVehicle() && !p.isTouchingWater()
                && !p.isInLava() && !p.isClimbing() && !p.isGliding();
    }

    /**
     * @param mode OFF / WAIT / JUMP
     * @return true — можно бить прямо сейчас
     */
    public static boolean prepare(ClientPlayerEntity p, String mode, boolean unsprint) {
        if ("OFF".equalsIgnoreCase(mode)) return true;
        if (unsprint && p.isSprinting()) p.setSprinting(false);
        if (canCrit(p)) return true;
        if ("JUMP".equalsIgnoreCase(mode) && canJump(p)) p.jump();
        return false;
    }
}
