package ru.duo.aura.modules;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.RotationHelper;
import ru.duo.aura.core.Setting;

/** Когда противник встал в щит — переключается на топор и ломает блок. */
public class ShieldDisabler extends Module {

    public final Setting.Num range = add(new Setting.Num("Range", 4, 2, 6, 0.1));
    public final Setting.Bool restoreSlot = add(new Setting.Bool("Restore slot", true));
    public final Setting.Bool silent = add(new Setting.Bool("Silent rotations", true));

    public ShieldDisabler() {
        super("ShieldDisabler", "Сбивает щит топором", Category.SWORD, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) return;
        if (p.getAttackCooldownProgress(0f) < 1f) return;

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof PlayerEntity pl) || pl == p || !pl.isAlive()) continue;
            if (p.distanceTo(pl) > range.value) continue;
            if (!pl.isBlocking()) continue;

            int axe = -1;
            for (int i = 0; i < 9; i++) {
                if (p.getInventory().getStack(i).getItem() instanceof AxeItem) { axe = i; break; }
            }
            if (axe < 0) return;

            int prev = p.getInventory().getSelectedSlot();
            p.getInventory().setSelectedSlot(axe);
            if (silent.value) RotationHelper.silentLook(p, pl);
            mc.interactionManager.attackEntity(p, pl);
            p.swingHand(Hand.MAIN_HAND);
            if (restoreSlot.value) p.getInventory().setSelectedSlot(prev);
            return;
        }
    }
}
