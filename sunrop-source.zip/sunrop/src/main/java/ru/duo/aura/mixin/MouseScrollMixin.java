package ru.duo.aura.mixin;

import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.duo.aura.core.ModuleManager;

/** Колесо мыши переключает цель килл-ауры, если включён Scroll switch. */
@Mixin(Mouse.class)
public class MouseScrollMixin {

    @Inject(method = "onMouseScroll", at = @At("HEAD"), cancellable = true)
    private void sunrop$scroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        if (vertical == 0) return;
        try {
            if (ModuleManager.killAura != null && ModuleManager.killAura.onScroll(vertical)) ci.cancel();
        } catch (Throwable ignored) {
        }
    }
}
