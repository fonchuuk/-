package ru.duo.aura.modules;

import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/** Всегда спринт, без зажатого Ctrl. */
public class AutoSprint extends Module {

    public final Setting.Bool keepWhenHungry = add(new Setting.Bool("Even when hungry", false));

    public AutoSprint() {
        super("AutoSprint", "Автоматический спринт", Category.OPTIMIZER, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null) return;
        if (p.isSneaking() || p.isTouchingWater() || p.isUsingItem()) return;
        if (!keepWhenHungry.value && p.getHungerManager().getFoodLevel() <= 6) return;
        if (p.getVelocity().horizontalLengthSquared() > 0.0008 && mc.options.forwardKey.isPressed()) {
            p.setSprinting(true);
        }
    }
}
