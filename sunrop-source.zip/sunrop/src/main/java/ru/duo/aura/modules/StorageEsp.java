package ru.duo.aura.modules;

import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/** Подсветка сундуков, бочек, шалкеров, воронок и спавнеров. */
public class StorageEsp extends Module {

    public final Setting.Num range = add(new Setting.Num("Range", 40, 8, 96, 1));
    public final Setting.Bool chests = add(new Setting.Bool("Chests", true));
    public final Setting.Bool barrels = add(new Setting.Bool("Barrels", true));
    public final Setting.Bool shulkers = add(new Setting.Bool("Shulkers", true));
    public final Setting.Bool hoppers = add(new Setting.Bool("Hoppers", false));
    public final Setting.Bool furnaces = add(new Setting.Bool("Furnaces", false));
    public final Setting.Bool spawners = add(new Setting.Bool("Spawners", true));
    public final Setting.Bool fill = add(new Setting.Bool("Fill", true));
    public final Setting.Bool names = add(new Setting.Bool("Names", false));

    public StorageEsp() {
        super("StorageEsp", "Подсветка сундуков и спавнеров", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
    }
}
