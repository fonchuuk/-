package ru.duo.aura.core;

/** Вкладки ClickGUI — как у System. */
public enum Category {
    SWORD("Sword"),
    CRYSTAL("Crystal"),
    OPTIMIZER("Optimizer"),
    FARM("Farm"),
    RENDER("Render"),
    CLIENT("Client");

    public final String title;

    Category(String title) {
        this.title = title;
    }
}
