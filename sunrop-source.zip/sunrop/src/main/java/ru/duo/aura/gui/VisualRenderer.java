package ru.duo.aura.gui;

import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.WorldChunk;
import ru.duo.aura.core.ModuleManager;
import ru.duo.aura.core.HudLayout;
import ru.duo.aura.core.Theme;

import java.util.ArrayList;
import java.util.List;

/** Отрисовка всех визуальных модулей (HUD + проекция в мир). */
public class VisualRenderer {

    private static final List<Object[]> STORAGE = new ArrayList<>(); // {BlockPos, color, name}
    private static long lastStorageScan = 0;
    private static final long[] CLICKS = new long[40];
    private static int clickIdx = 0;
    private static boolean lastAttack = false;

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        try {
            countClicks(mc);
            storageEsp(ctx, mc);
            waypoints(ctx, mc);
            if (mc.options.hudHidden) return;
            targetMarker(ctx, mc);
            crosshair(ctx, mc);
            targetHud(ctx, mc);
            armorHud(ctx, mc);
            keyStrokes(ctx, mc);
            infoHud(ctx, mc);
        } catch (Throwable t) {
            System.err.println("[Sunrop] визуал: " + t);
        }
    }

    // ------------------------------------------------------------ CPS

    private static void countClicks(MinecraftClient mc) {
        boolean now = mc.options.attackKey.isPressed();
        if (now && !lastAttack) {
            CLICKS[clickIdx++ % CLICKS.length] = System.currentTimeMillis();
        }
        lastAttack = now;
    }

    private static int cps() {
        long now = System.currentTimeMillis();
        int n = 0;
        for (long c : CLICKS) if (c > 0 && now - c <= 1000) n++;
        return n;
    }

    // ------------------------------------------------------------ прицел

    private static void crosshair(DrawContext ctx, MinecraftClient mc) {
        var m = ModuleManager.crosshair;
        if (m == null || !m.isEnabled()) return;
        if (mc.options.getPerspective() != null && !mc.options.getPerspective().isFirstPerson()) return;

        int cx = ctx.getScaledWindowWidth() / 2;
        int cy = ctx.getScaledWindowHeight() / 2;
        int color = m.accentColor.value ? Theme.accent() : 0xFFFFFFFF;
        int g = m.gap.asInt(), l = m.length.asInt(), t = m.thickness.asInt();

        switch (m.style.get()) {
            case "DOT" -> ctx.fill(cx - t, cy - t, cx + t, cy + t, color);
            case "CIRCLE" -> {
                int r = Math.max(2, l);
                for (int i = 0; i < 360; i += 6) {
                    int px = cx + (int) Math.round(Math.cos(Math.toRadians(i)) * r);
                    int py = cy + (int) Math.round(Math.sin(Math.toRadians(i)) * r);
                    ctx.fill(px, py, px + t, py + t, color);
                }
            }
            default -> {
                ctx.fill(cx - g - l, cy, cx - g, cy + t, color);
                ctx.fill(cx + g, cy, cx + g + l, cy + t, color);
                ctx.fill(cx, cy - g - l, cx + t, cy - g, color);
                ctx.fill(cx, cy + g, cx + t, cy + g + l, color);
            }
        }
    }

    // ------------------------------------------------------------ цель

    private static void targetHud(DrawContext ctx, MinecraftClient mc) {
        var m = ModuleManager.targetHud;
        if (m == null || !m.isEnabled()) return;
        LivingEntity t = ru.duo.aura.core.TargetTracker.get();
        if (t == null) return;
        String src = ru.duo.aura.core.TargetTracker.source();

        int w = 142, h = m.reactionBar.value && src.equals("TriggerBot") ? 46 : 40;
        int x = HudLayout.x(HudLayout.TARGET_HUD, ctx.getScaledWindowWidth() / 2 + 24, w, h);
        int y = HudLayout.y(HudLayout.TARGET_HUD, ctx.getScaledWindowHeight() / 2 + m.offsetY.asInt());

        Draw.shadow(ctx, x, y, x + w, y + h, 4);
        Draw.round(ctx, x, y, x + w, y + h, 4, Theme.alpha(Theme.panel(), 230));
        Draw.round(ctx, x, y, x + 2, y + h, 1, Theme.accent());

        String name = t.getName().getString();
        ctx.drawText(mc.textRenderer, name, x + 8, y + 6, Theme.text(), false);

        if (m.showSource.value && !src.isEmpty()) {
            String tag = src.equals("TriggerBot") ? "TRIGGER" : "AURA";
            boolean pin = ModuleManager.killAura != null && ModuleManager.killAura.isPinned()
                    && src.equals("KillAura");
            if (pin) tag += " \u00b7 LOCK";
            int tw = mc.textRenderer.getWidth(tag);
            ctx.drawText(mc.textRenderer, tag, x + w - tw - 8, y + 6, Theme.accent(), false);
        }

        float f = Math.max(0f, Math.min(1f, t.getHealth() / Math.max(1f, t.getMaxHealth())));
        if (m.healthBar.value) {
            int bx = x + 8, bw = w - 16;
            Draw.round(ctx, bx, y + 19, bx + bw, y + 24, 2, Theme.border());
            int hc = 0xFF000000 | ((int) (255 * (1 - f)) << 16) | ((int) (200 * f) << 8) | 60;
            Draw.round(ctx, bx, y + 19, bx + (int) (bw * f), y + 24, 2, hc);
        }
        String info = ((int) Math.ceil(t.getHealth())) + " HP";
        if (m.distance.value && mc.player != null) {
            info += "   " + String.format("%.1f", mc.player.distanceTo(t)) + " \u043c";
        }
        ctx.drawText(mc.textRenderer, info, x + 8, y + 27, Theme.textDim(), false);

        // полоска «реакции» триггербота: видно, когда он вот-вот ударит
        if (m.reactionBar.value && src.equals("TriggerBot") && ModuleManager.triggerBot != null) {
            float pr = Math.max(0f, Math.min(1f, ModuleManager.triggerBot.reactionProgress));
            int bx = x + 8, bw = w - 16;
            Draw.round(ctx, bx, y + 38, bx + bw, y + 41, 1, Theme.border());
            Draw.round(ctx, bx, y + 38, bx + (int) (bw * pr), y + 41, 1,
                    pr >= 1f ? 0xFF55FF88 : Theme.accent());
        }
    }

    // --------------------------------------------------- подсветка цели в мире

    private static void targetMarker(DrawContext ctx, MinecraftClient mc) {
        var m = ModuleManager.targetHud;
        if (m == null || !m.isEnabled() || !m.marker.value) return;
        LivingEntity t = ru.duo.aura.core.TargetTracker.get();
        if (t == null || mc.gameRenderer == null) return;
        String src = ru.duo.aura.core.TargetTracker.source();

        Camera cam = mc.gameRenderer.getCamera();
        if (cam == null) return;
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        EspRenderer.Projector proj = EspRenderer.Projector.of(cam, sw, sh);

        float tick = mc.getRenderTickCounter().getTickProgress(true);
        Vec3d pos = new Vec3d(
                net.minecraft.util.math.MathHelper.lerp(tick, t.lastX, t.getX()),
                net.minecraft.util.math.MathHelper.lerp(tick, t.lastY, t.getY()),
                net.minecraft.util.math.MathHelper.lerp(tick, t.lastZ, t.getZ()));
        float bw = t.getWidth(), bh = t.getHeight();
        float[] r = m.markerMode.is("CORNERS")
                ? proj.cornerBox(pos, bw, bh)
                : proj.staticBox(pos, bw, bh);
        if (r == null) return;

        // триггер — зелёный, аура — акцент клиента; пульсация, чтобы было заметно
        int base = src.equals("TriggerBot") ? 0xFF4CE07A : Theme.accent();
        float pulse = 0.55f + 0.45f * (float) Math.sin(System.currentTimeMillis() / 180.0);
        int a = (int) (110 + 110 * pulse);
        int col = (a << 24) | (base & 0xFFFFFF);

        int x1 = (int) r[0], y1 = (int) r[1], x2 = (int) r[2], y2 = (int) r[3];
        if (m.markerMode.is("GLOW")) {
            ctx.fill(x1, y1, x2, y2, (40 + a / 4) << 24 | (base & 0xFFFFFF));
        }
        if (m.markerMode.is("CORNERS")) {
            int len = Math.max(3, (y2 - y1) / 5);
            ctx.fill(x1, y1, x1 + len, y1 + 1, col);
            ctx.fill(x1, y1, x1 + 1, y1 + len, col);
            ctx.fill(x2 - len, y1, x2, y1 + 1, col);
            ctx.fill(x2 - 1, y1, x2, y1 + len, col);
            ctx.fill(x1, y2 - 1, x1 + len, y2, col);
            ctx.fill(x1, y2 - len, x1 + 1, y2, col);
            ctx.fill(x2 - len, y2 - 1, x2, y2, col);
            ctx.fill(x2 - 1, y2 - len, x2, y2, col);
        } else {
            ctx.fill(x1, y1, x2, y1 + 1, col);
            ctx.fill(x1, y2 - 1, x2, y2, col);
            ctx.fill(x1, y1, x1 + 1, y2, col);
            ctx.fill(x2 - 1, y1, x2, y2, col);
        }

        // полоска здоровья над целью
        float hf = Math.max(0f, Math.min(1f, t.getHealth() / Math.max(1f, t.getMaxHealth())));
        int hx1 = x1, hx2 = x2, hy = y1 - 4;
        if (hx2 - hx1 > 6 && hy > 2) {
            ctx.fill(hx1, hy, hx2, hy + 2, 0xAA101014);
            int hc = 0xFF000000 | ((int) (255 * (1 - hf)) << 16) | ((int) (210 * hf) << 8) | 70;
            ctx.fill(hx1, hy, hx1 + (int) ((hx2 - hx1) * hf), hy + 2, hc);
        }
    }

    // ------------------------------------------------------------ броня

    private static void armorHud(DrawContext ctx, MinecraftClient mc) {
        var m = ModuleManager.armorHud;
        if (m == null || !m.isEnabled()) return;

        List<ItemStack> stacks = new ArrayList<>();
        for (net.minecraft.entity.EquipmentSlot slot : new net.minecraft.entity.EquipmentSlot[]{
                net.minecraft.entity.EquipmentSlot.HEAD, net.minecraft.entity.EquipmentSlot.CHEST,
                net.minecraft.entity.EquipmentSlot.LEGS, net.minecraft.entity.EquipmentSlot.FEET}) {
            ItemStack s = mc.player.getEquippedStack(slot);
            if (!s.isEmpty()) stacks.add(s);
        }
        if (m.mainHand.value && !mc.player.getMainHandStack().isEmpty()) {
            stacks.add(mc.player.getMainHandStack());
        }
        if (stacks.isEmpty()) return;

        int total = stacks.size() * 20;
        int x = HudLayout.x(HudLayout.ARMOR, ctx.getScaledWindowWidth() / 2 - total / 2, total, 20);
        int y = HudLayout.y(HudLayout.ARMOR, ctx.getScaledWindowHeight() - m.offsetY.asInt());

        for (ItemStack s : stacks) {
            ctx.drawItem(s, x, y);
            if (m.durability.value && s.isDamageable()) {
                int max = s.getMaxDamage();
                int left = max - s.getDamage();
                float f = left / (float) max;
                int bc = 0xFF000000 | ((int) (255 * (1 - f)) << 16) | ((int) (220 * f) << 8);
                ctx.fill(x, y + 17, x + 16, y + 19, 0xAA101010);
                ctx.fill(x, y + 17, x + (int) (16 * f), y + 19, bc);
                String txt = String.valueOf(left);
                ctx.drawText(mc.textRenderer, txt, x + 8 - mc.textRenderer.getWidth(txt) / 2, y - 9, bc, true);
            }
            x += 20;
        }
    }

    // ------------------------------------------------------------ клавиши

    private static void keyStrokes(DrawContext ctx, MinecraftClient mc) {
        var m = ModuleManager.keyStrokes;
        if (m == null || !m.isEnabled()) return;

        int s = m.size.asInt(), gap = 2;
        int x = HudLayout.x(HudLayout.KEYSTROKES, m.x.asInt(), (s + gap) * 3, (s + gap) * 4);
        int y = HudLayout.y(HudLayout.KEYSTROKES, m.y.asInt());

        key(ctx, mc, x + s + gap, y, s, s, "W", mc.options.forwardKey.isPressed());
        key(ctx, mc, x, y + s + gap, s, s, "A", mc.options.leftKey.isPressed());
        key(ctx, mc, x + s + gap, y + s + gap, s, s, "S", mc.options.backKey.isPressed());
        key(ctx, mc, x + (s + gap) * 2, y + s + gap, s, s, "D", mc.options.rightKey.isPressed());

        int row = y + (s + gap) * 2;
        if (m.mouse.value) {
            int half = s + gap / 2;
            key(ctx, mc, x, row, half + gap / 2, s, m.cps.value ? String.valueOf(cps()) : "L",
                    mc.options.attackKey.isPressed());
            key(ctx, mc, x + s + gap + gap / 2, row, half + gap / 2, s, "R", mc.options.useKey.isPressed());
            row += s + gap;
        }
        if (m.space.value) {
            key(ctx, mc, x, row, (s + gap) * 3 - gap, s / 2 + 3, "_", mc.options.jumpKey.isPressed());
        }
    }

    private static void key(DrawContext ctx, MinecraftClient mc, int x, int y, int w, int h,
                            String label, boolean down) {
        int bg = down ? Theme.alpha(Theme.accent(), 220) : 0x77101218;
        Draw.round(ctx, x, y, x + w, y + h, 3, bg);
        int tx = x + w / 2 - mc.textRenderer.getWidth(label) / 2;
        ctx.drawText(mc.textRenderer, label, tx, y + h / 2 - 4, down ? 0xFF101218 : 0xFFE8EAF2, false);
    }

    // ------------------------------------------------------------ инфо

    private static void infoHud(DrawContext ctx, MinecraftClient mc) {
        var m = ModuleManager.infoHud;
        if (m == null || !m.isEnabled()) return;

        List<String> lines = new ArrayList<>();
        var p = mc.player;
        if (m.coords.value) lines.add(String.format("XYZ  %.0f  %.0f  %.0f", p.getX(), p.getY(), p.getZ()));
        if (m.netherCoords.value) {
            boolean nether = mc.world.getRegistryKey().getValue().getPath().contains("nether");
            double k = nether ? 8.0 : 0.125;
            lines.add(String.format(nether ? "Overworld  %.0f  %.0f" : "Nether  %.0f  %.0f",
                    p.getX() * k, p.getZ() * k));
        }
        if (m.direction.value) {
            lines.add("Взгляд  " + p.getHorizontalFacing().asString().toUpperCase()
                    + String.format("  (%.0f°)", net.minecraft.util.math.MathHelper.wrapDegrees(p.getYaw())));
        }
        if (m.speed.value) {
            Vec3d v = p.getVelocity();
            double bps = Math.sqrt(v.x * v.x + v.z * v.z) * 20.0;
            lines.add(String.format("Скорость  %.2f бл/с", bps));
        }
        if (m.fps.value) lines.add(mc.getCurrentFps() + " FPS");
        if (m.ping.value && mc.getNetworkHandler() != null) {
            var e = mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
            lines.add((e == null ? 0 : e.getLatency()) + " ms");
        }
        if (lines.isEmpty()) return;

        int wMax = 0;
        for (String l : lines) wMax = Math.max(wMax, mc.textRenderer.getWidth(l));
        int w = wMax + 12, h = lines.size() * 10 + 7;
        boolean right = m.corner.get().endsWith("RIGHT");
        boolean bottom = m.corner.get().startsWith("BOTTOM");
        int x = HudLayout.x(HudLayout.INFO, right ? ctx.getScaledWindowWidth() - w - 4 : 4, w, h);
        int y = HudLayout.y(HudLayout.INFO, bottom ? ctx.getScaledWindowHeight() - h - 4 : 26);

        Draw.round(ctx, x, y, x + w, y + h, 4, Theme.alpha(Theme.panel(), 190));
        Draw.round(ctx, x, y, x + 2, y + h, 1, Theme.accent());
        int ly = y + 4;
        for (String l : lines) {
            ctx.drawText(mc.textRenderer, l, x + 7, ly, Theme.text(), false);
            ly += 10;
        }
    }

    // ------------------------------------------------------------ метки

    private static void waypoints(DrawContext ctx, MinecraftClient mc) {
        var m = ModuleManager.waypoints;
        if (m == null || !m.isEnabled() || m.points.isEmpty()) return;
        Camera cam = mc.gameRenderer.getCamera();
        if (cam == null || !cam.isReady()) return;
        var proj = EspRenderer.Projector.of(cam, ctx.getScaledWindowWidth(), ctx.getScaledWindowHeight());
        if (proj == null) return;

        for (var wp : m.points) {
            double dist = mc.player.getEntityPos().distanceTo(wp.pos());
            if (dist > m.maxDistance.value) continue;
            float[] s = proj.project(wp.pos().x, wp.pos().y + 1.2, wp.pos().z);
            if (s == null) continue;

            String label = wp.name();
            if (m.showDistance.value) label += "  " + (int) dist + " м";
            int tw = mc.textRenderer.getWidth(label);
            int x = (int) s[0], y = (int) s[1];
            Draw.round(ctx, x - tw / 2 - 4, y - 6, x + tw / 2 + 4, y + 6, 3,
                    Theme.alpha(Theme.panel(), 210));
            ctx.drawText(mc.textRenderer, label, x - tw / 2, y - 4, Theme.accent(), false);
            ctx.fill(x - 1, y + 6, x + 1, y + 14, Theme.alpha(Theme.accent(), 180));
        }
    }

    // ------------------------------------------------------------ сундуки

    private static void storageEsp(DrawContext ctx, MinecraftClient mc) {
        var m = ModuleManager.storageEsp;
        if (m == null || !m.isEnabled()) { STORAGE.clear(); return; }
        Camera cam = mc.gameRenderer.getCamera();
        if (cam == null || !cam.isReady()) return;
        var proj = EspRenderer.Projector.of(cam, ctx.getScaledWindowWidth(), ctx.getScaledWindowHeight());
        if (proj == null) return;

        long now = System.currentTimeMillis();
        if (now - lastStorageScan > 700) {
            lastStorageScan = now;
            scanStorage(mc, m);
        }

        for (Object[] o : STORAGE) {
            BlockPos pos = (BlockPos) o[0];
            int color = (Integer) o[1];
            float[] r = proj.cornerBox(new Vec3d(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5), 1f, 1f);
            if (r == null) continue;
            int x1 = (int) r[0], y1 = (int) r[1], x2 = (int) r[2], y2 = (int) r[3];
            if (x2 - x1 < 1 || y2 - y1 < 1) continue;
            Draw.corners(ctx, x1, y1, x2, y2, color, m.fill.value);
            if (m.names.value) {
                String name = (String) o[2];
                int tw = mc.textRenderer.getWidth(name);
                ctx.drawText(mc.textRenderer, name, (x1 + x2) / 2 - tw / 2, y1 - 10, color, true);
            }
        }
    }

    private static void scanStorage(MinecraftClient mc, ru.duo.aura.modules.StorageEsp m) {
        STORAGE.clear();
        int r = m.range.asInt();
        double rSq = (double) r * r;
        BlockPos self = mc.player.getBlockPos();
        int cr = Math.max(1, r / 16 + 1);
        ChunkPos center = new ChunkPos(self);

        for (int cx = center.x - cr; cx <= center.x + cr; cx++) {
            for (int cz = center.z - cr; cz <= center.z + cr; cz++) {
                WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cx, cz);
                if (chunk == null) continue;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    if (be.getPos().getSquaredDistance(self) > rSq) continue;
                    BlockEntityType<?> type = be.getType();
                    int color;
                    String name;
                    if (type == BlockEntityType.CHEST || type == BlockEntityType.TRAPPED_CHEST
                            || type == BlockEntityType.ENDER_CHEST) {
                        if (!m.chests.value) continue;
                        color = 0xFFFFC04D; name = "Сундук";
                    } else if (type == BlockEntityType.BARREL) {
                        if (!m.barrels.value) continue;
                        color = 0xFFD2A24C; name = "Бочка";
                    } else if (type == BlockEntityType.SHULKER_BOX) {
                        if (!m.shulkers.value) continue;
                        color = 0xFFC060FF; name = "Шалкер";
                    } else if (type == BlockEntityType.HOPPER) {
                        if (!m.hoppers.value) continue;
                        color = 0xFF9AA0B0; name = "Воронка";
                    } else if (type == BlockEntityType.FURNACE || type == BlockEntityType.BLAST_FURNACE
                            || type == BlockEntityType.SMOKER) {
                        if (!m.furnaces.value) continue;
                        color = 0xFFB0B0B0; name = "Печь";
                    } else if (type == BlockEntityType.MOB_SPAWNER || type == BlockEntityType.TRIAL_SPAWNER) {
                        if (!m.spawners.value) continue;
                        color = 0xFF4DFFC4; name = "Спавнер";
                    } else {
                        continue;
                    }
                    STORAGE.add(new Object[]{be.getPos(), color, name});
                    if (STORAGE.size() >= 200) return;
                }
            }
        }
    }
}
