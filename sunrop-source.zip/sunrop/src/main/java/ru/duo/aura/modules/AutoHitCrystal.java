package ru.duo.aura.modules;

import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.RotationHelper;
import ru.duo.aura.core.Setting;

/** Бьёт по кристаллам рядом, не трогая всё остальное. */
public class AutoHitCrystal extends Module {

    public final Setting.Num range = add(new Setting.Num("Range", 4.5, 2, 6, 0.1));
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 1, 0, 20, 1));
    public final Setting.Bool silent = add(new Setting.Bool("Silent rotations", true));
    public final Setting.Bool onlyOthers = add(new Setting.Bool("Skip own placements", false));

    private int timer;

    public AutoHitCrystal() {
        super("AutoHitCrystal", "Подрывает кристаллы рядом", Category.CRYSTAL, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) return;
        if (timer-- > 0) return;

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof EndCrystalEntity c)) continue;
            if (p.distanceTo(c) > range.value) continue;
            if (onlyOthers.value && c.age < 10) continue;

            if (silent.value) RotationHelper.silentLook(p, c);
            mc.interactionManager.attackEntity(p, c);
            p.swingHand(Hand.MAIN_HAND);
            timer = delay.asInt();
            return;
        }
    }
}
