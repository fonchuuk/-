package ru.duo.aura.modules;

import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/** Не даёт серверу кикнуть за бездействие. */
public class AntiAFK extends Module {

    public final Setting.Num interval = add(new Setting.Num("Interval (sec)", 25, 3, 120, 1));
    public final Setting.Bool swing = add(new Setting.Bool("Swing hand", true));
    public final Setting.Bool jump = add(new Setting.Bool("Jump", true));
    public final Setting.Bool rotate = add(new Setting.Bool("Rotate", true));

    private int tick;

    public AntiAFK() {
        super("AntiAFK", "Имитирует активность, чтобы не кикнуло", Category.OPTIMIZER, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (++tick < interval.asInt() * 20) return;
        tick = 0;
        if (rotate.value) mc.player.setYaw(mc.player.getYaw() + (Math.random() > 0.5 ? 12f : -12f));
        if (swing.value) mc.player.swingHand(Hand.MAIN_HAND);
        if (jump.value && mc.player.isOnGround()) mc.player.jump();
    }
}
