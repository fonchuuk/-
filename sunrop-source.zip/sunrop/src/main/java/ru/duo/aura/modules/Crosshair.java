package ru.duo.aura.modules;

import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/** Свой прицел поверх ванильного. */
public class Crosshair extends Module {

    public final Setting.Mode style = add(new Setting.Mode("Style", 0, "CROSS", "DOT", "CIRCLE"));
    public final Setting.Num gap = add(new Setting.Num("Gap", 3, 0, 10, 1));
    public final Setting.Num length = add(new Setting.Num("Length", 5, 1, 14, 1));
    public final Setting.Num thickness = add(new Setting.Num("Thickness", 1, 1, 3, 1));
    public final Setting.Bool accentColor = add(new Setting.Bool("Accent color", true));

    public Crosshair() {
        super("Crosshair", "Кастомный прицел", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
    }
}
