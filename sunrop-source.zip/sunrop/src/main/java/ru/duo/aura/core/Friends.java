package ru.duo.aura.core;

import net.minecraft.client.MinecraftClient;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashSet;
import java.util.Set;

/** Список друзей: config/sunrop-friends.txt, по нику на строку. */
public class Friends {

    private static final Set<String> NAMES = new LinkedHashSet<>();
    private static long lastLoad = 0;

    private static Path path() {
        return MinecraftClient.getInstance().runDirectory.toPath()
                .resolve("config").resolve("sunrop-friends.txt");
    }

    public static void load() {
        try {
            Path p = path();
            if (!Files.exists(p)) {
                Files.createDirectories(p.getParent());
                Files.writeString(p, "# По нику на строку — их не трогают аура и триггербот\n");
                NAMES.clear();
                return;
            }
            NAMES.clear();
            for (String line : Files.readAllLines(p)) {
                String s = line.trim();
                if (s.isEmpty() || s.startsWith("#")) continue;
                NAMES.add(s.toLowerCase());
            }
        } catch (Exception ignored) {}
        lastLoad = System.currentTimeMillis();
    }

    public static void reloadIfStale() {
        if (System.currentTimeMillis() - lastLoad > 3000) load();
    }

    public static boolean is(String name) {
        if (name == null) return false;
        reloadIfStale();
        return NAMES.contains(name.toLowerCase());
    }

    public static java.util.List<String> all() {
        reloadIfStale();
        return new java.util.ArrayList<>(NAMES);
    }

    public static int count() {
        reloadIfStale();
        return NAMES.size();
    }

    public static Path file() { return path(); }

    public static boolean toggle(String name) {
        reloadIfStale();
        String key = name.toLowerCase();
        boolean added;
        if (NAMES.contains(key)) { NAMES.remove(key); added = false; }
        else { NAMES.add(key); added = true; }
        try {
            StringBuilder sb = new StringBuilder("# По нику на строку — их не трогают аура и триггербот\n");
            for (String n : NAMES) sb.append(n).append('\n');
            Files.createDirectories(path().getParent());
            Files.writeString(path(), sb.toString());
        } catch (Exception ignored) {}
        return added;
    }
}
