package ru.duo.aura.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Позиции HUD-элементов на экране. Элементы двигаются мышью в редакторе
 * (gui/HudEditor) и сохраняются в конфиг строками вида hud.Имя=x,y.
 */
public class HudLayout {

    /** Элемент: имя, подпись, позиция и последний отрисованный размер. */
    public static class Element {
        public final String id;
        public final String title;
        public int x, y;
        public int w = 60, h = 12;
        public final int defX, defY;

        Element(String id, String title, int x, int y) {
            this.id = id; this.title = title;
            this.x = x; this.y = y;
            this.defX = x; this.defY = y;
        }
    }

    private static final Map<String, Element> ELEMENTS = new LinkedHashMap<>();

    public static final String WATERMARK = "Watermark";
    public static final String ARRAYLIST = "ArrayList";
    public static final String TARGET_INFO = "TargetInfo";
    public static final String KEYSTROKES = "KeyStrokes";
    public static final String INFO = "InfoHud";
    public static final String SERVER = "ServerHud";
    public static final String ARMOR = "ArmorHud";
    public static final String TARGET_HUD = "TargetHud";

    static {
        add(WATERMARK, "Логотип", 3, 3);
        add("Coords", "Координаты (HUD)", 3, -6);
        add(ARRAYLIST, "Список модулей", -1, 2);          // -1 = прижат вправо
        add(TARGET_INFO, "Строка цели", -2, -2);          // -2 = по центру
        add(KEYSTROKES, "Клавиши", 8, 120);
        add(INFO, "Инфо-панель", 4, -3);                  // -3 = снизу слева
        add(ARMOR, "Броня", -2, -4);
        add(TARGET_HUD, "Карточка цели", -2, -5);
    }

    private static void add(String id, String title, int x, int y) {
        ELEMENTS.put(id, new Element(id, title, x, y));
    }

    public static Element get(String id) {
        return ELEMENTS.get(id);
    }

    public static List<Element> all() {
        return new ArrayList<>(ELEMENTS.values());
    }

    /**
     * Готовая позиция X с учётом «магических» значений по умолчанию.
     * @param fallbackX куда класть элемент, если позиция ещё не задана вручную
     */
    public static int x(String id, int fallbackX, int w, int h) {
        Element e = ELEMENTS.get(id);
        if (e == null) return fallbackX;
        e.w = w; e.h = h;
        if (e.x < 0) e.x = fallbackX;
        return e.x;
    }

    public static int y(String id, int fallbackY) {
        Element e = ELEMENTS.get(id);
        if (e == null) return fallbackY;
        if (e.y < 0) e.y = fallbackY;
        return e.y;
    }

    /** Строки для конфига. */
    public static List<String> serialize() {
        List<String> out = new ArrayList<>();
        for (Element e : ELEMENTS.values()) out.add("hud." + e.id + "=" + e.x + "," + e.y);
        return out;
    }

    public static void deserialize(String id, String value) {
        Element e = ELEMENTS.get(id);
        if (e == null) return;
        String[] parts = value.split(",");
        if (parts.length != 2) return;
        try {
            e.x = Integer.parseInt(parts[0].trim());
            e.y = Integer.parseInt(parts[1].trim());
        } catch (NumberFormatException ignored) {}
    }

    public static void reset() {
        for (Element e : ELEMENTS.values()) { e.x = e.defX; e.y = e.defY; }
    }

    /** Не даём утащить элемент за экран. */
    public static void clamp(int screenW, int screenH) {
        for (Element e : ELEMENTS.values()) {
            e.x = Math.max(0, Math.min(e.x, Math.max(0, screenW - 10)));
            e.y = Math.max(0, Math.min(e.y, Math.max(0, screenH - 8)));
        }
    }
}
