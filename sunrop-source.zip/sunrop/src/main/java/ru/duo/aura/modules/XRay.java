package ru.duo.aura.modules;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/** Оставляет видимыми только руды и выбранные блоки. */
public class XRay extends Module {

    public final Setting.Bool ores = add(new Setting.Bool("Ores", true));
    public final Setting.Bool ancientDebris = add(new Setting.Bool("Ancient debris", true));
    public final Setting.Bool chests = add(new Setting.Bool("Chests", true));
    public final Setting.Bool spawners = add(new Setting.Bool("Spawners", true));
    public final Setting.Bool portals = add(new Setting.Bool("Portals", true));
    public final Setting.Bool liquids = add(new Setting.Bool("Lava/water", false));
    public final Setting.Bool fullbright = add(new Setting.Bool("Force fullbright", true));

    public XRay() {
        super("XRay", "Видно только руду и ценные блоки", Category.OPTIMIZER, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onEnable() { reload(); }

    @Override
    public void onDisable() { reload(); }

    private void reload() {
        if (mc.worldRenderer != null) mc.worldRenderer.reload();
    }

    @Override
    public void onTick() {
        // без света под землёй xray бесполезен — подтягиваем Fullbright
        if (fullbright.value && ru.duo.aura.core.ModuleManager.fullbright != null
                && !ru.duo.aura.core.ModuleManager.fullbright.isEnabled()) {
            ru.duo.aura.core.ModuleManager.fullbright.setEnabled(true);
        }
    }

    /** Рисовать ли этот блок. */
    public boolean shows(BlockState st) {
        String id = st.getBlock().toString().toLowerCase();
        if (ores.value && id.contains("_ore")) return true;
        if (ancientDebris.value && id.contains("ancient_debris")) return true;
        if (chests.value && (id.contains("chest") || id.contains("barrel") || id.contains("shulker"))) return true;
        if (spawners.value && id.contains("spawner")) return true;
        if (portals.value && (id.contains("portal") || st.isOf(Blocks.END_PORTAL_FRAME))) return true;
        if (liquids.value && !st.getFluidState().isEmpty()) return true;
        return false;
    }
}
