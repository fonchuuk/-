package ru.duo.aura.modules;

import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Friends;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.ModuleManager;
import ru.duo.aura.core.RotationHelper;
import ru.duo.aura.core.Setting;

/** Ставит и подрывает кристаллы рядом с целью. */
public class AutoCrystal extends Module {

    public final Setting.Num targetRange = add(new Setting.Num("Target range", 8, 3, 14, 0.5));
    public final Setting.Num placeRange = add(new Setting.Num("Place range", 4.5, 2, 6, 0.1));
    public final Setting.Num breakRange = add(new Setting.Num("Break range", 4.5, 2, 6, 0.1));
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 2, 0, 20, 1));
    public final Setting.Num minDamage = add(new Setting.Num("Min damage", 4, 1, 20, 1));
    public final Setting.Num maxSelfDamage = add(new Setting.Num("Max self damage", 6, 0, 20, 1));
    public final Setting.Bool place = add(new Setting.Bool("Place", true));
    public final Setting.Bool breakCrystals = add(new Setting.Bool("Break", true));
    public final Setting.Bool silent = add(new Setting.Bool("Silent rotations", true));
    public final Setting.Bool players = add(new Setting.Bool("Players", true));
    public final Setting.Bool mobs = add(new Setting.Bool("Mobs", false));

    private int timer;

    public AutoCrystal() {
        super("AutoCrystal", "Ставит и взрывает кристаллы", Category.CRYSTAL, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) return;
        if (timer-- > 0) return;

        LivingEntity target = findTarget(p);
        if (target == null) return;

        // 1. взорвать уже стоящий кристалл
        if (breakCrystals.value) {
            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof EndCrystalEntity c)) continue;
                if (p.distanceTo(c) > breakRange.value) continue;
                if (c.distanceTo(target) > 6) continue;
                if (selfDamage(c.getEntityPos()) > maxSelfDamage.value) continue;

                if (silent.value) RotationHelper.silentLook(p, c);
                mc.interactionManager.attackEntity(p, c);
                p.swingHand(Hand.MAIN_HAND);
                timer = delay.asInt();
                return;
            }
        }

        // 2. поставить новый
        if (!place.value) return;
        int slot = findCrystal(p);
        if (slot < 0) return;

        BlockPos best = null;
        double bestScore = minDamage.value;
        BlockPos self = p.getBlockPos();
        int r = (int) Math.ceil(placeRange.value);

        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -3; dy <= 3; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    BlockPos pos = self.add(dx, dy, dz);
                    if (!canPlace(pos)) continue;
                    if (p.getEyePos().distanceTo(Vec3d.ofCenter(pos)) > placeRange.value) continue;

                    Vec3d crystal = Vec3d.ofCenter(pos).add(0, 0.5, 0);
                    double dmg = damage(crystal, target.getEntityPos());
                    if (dmg < bestScore) continue;
                    if (selfDamage(crystal) > maxSelfDamage.value) continue;
                    bestScore = dmg;
                    best = pos;
                }
            }
        }
        if (best == null) return;

        int prev = p.getInventory().getSelectedSlot();
        p.getInventory().setSelectedSlot(slot);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
                new BlockHitResult(Vec3d.ofCenter(best).add(0, 0.5, 0), Direction.UP, best, false));
        p.swingHand(Hand.MAIN_HAND);
        p.getInventory().setSelectedSlot(prev);
        timer = delay.asInt();
    }

    private boolean canPlace(BlockPos pos) {
        var st = mc.world.getBlockState(pos);
        if (!st.isOf(Blocks.OBSIDIAN) && !st.isOf(Blocks.BEDROCK)) return false;
        if (!mc.world.getBlockState(pos.up()).isAir()) return false;
        for (Entity e : mc.world.getOtherEntities(null,
                new net.minecraft.util.math.Box(pos.up()))) {
            if (!(e instanceof net.minecraft.entity.ItemEntity)) return false;
        }
        return true;
    }

    /** Грубая оценка урона от взрыва 6-й силы. */
    private double damage(Vec3d crystal, Vec3d victim) {
        double d = crystal.distanceTo(victim);
        if (d > 12) return 0;
        double exposure = 1.0 - d / 12.0;
        return exposure * exposure * 48.0;
    }

    private double selfDamage(Vec3d crystal) {
        return mc.player == null ? 99 : damage(crystal, mc.player.getEntityPos());
    }

    private int findCrystal(PlayerEntity p) {
        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getStack(i).isOf(Items.END_CRYSTAL)) return i;
        }
        return -1;
    }

    private LivingEntity findTarget(PlayerEntity p) {
        LivingEntity best = null;
        double bestDist = targetRange.value;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive()) continue;
            if (le instanceof PlayerEntity pl) {
                if (!players.value) continue;
                if (ModuleManager.friendManager != null && ModuleManager.friendManager.isEnabled()
                        && ModuleManager.friendManager.protectFromAura.value
                        && Friends.is(pl.getName().getString())) continue;
            } else if (!mobs.value) continue;

            double d = p.distanceTo(le);
            if (d < bestDist) { bestDist = d; best = le; }
        }
        return best;
    }
}
