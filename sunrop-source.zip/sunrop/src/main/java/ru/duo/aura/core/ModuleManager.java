package ru.duo.aura.core;

import net.minecraft.client.MinecraftClient;
import ru.duo.aura.modules.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ModuleManager {

    public static final List<Module> MODULES = new ArrayList<>();
    public static boolean chatFeedback = true;

    public static KillAura killAura;
    public static TriggerBot triggerBot;
    public static HudList hudList;
    public static Fullbright fullbright;
    public static Esp esp;
    public static AutoTotem autoTotem;
    public static SeeInvis seeInvis;
    public static AutoFarm autoFarm;
    public static AppleFarmer appleFarmer;
    public static SandFarmer sandFarmer;
    public static AntiAFK antiAFK;
    public static SprintReset sprintReset;
    public static XRay xray;
    public static Freecam freecam;
    public static FriendManager friendManager;
    public static InventoryMove inventoryMove;
    public static Waypoints waypoints;
    public static AimAssist aimAssist;
    public static AutoCrystal autoCrystal;
    public static AutoHitCrystal autoHitCrystal;
    public static ShieldDisabler shieldDisabler;
    public static FasterXP fasterXP;
    public static GuiBind guiBind;
    public static Panic panic;
    public static Interface iface;
    public static NoHurtCam noHurtCam;
    public static Zoom zoom;
    public static TimeChanger timeChanger;
    public static WeatherChanger weatherChanger;
    public static KeyStrokes keyStrokes;
    public static InfoHud infoHud;
    public static ArmorHud armorHud;
    public static TargetHud targetHud;
    public static Crosshair crosshair;
    public static StorageEsp storageEsp;
    public static AutoSprint autoSprint;
    public static AutoTool autoTool;
    public static ChestStealer chestStealer;
    public static AutoRespawn autoRespawn;

    public static void init() {
        MODULES.clear();
        MODULES.add(killAura = new KillAura());
        MODULES.add(triggerBot = new TriggerBot());
        MODULES.add(autoTotem = new AutoTotem());
        MODULES.add(fullbright = new Fullbright());
        MODULES.add(esp = new Esp());
        MODULES.add(seeInvis = new SeeInvis());
        MODULES.add(autoFarm = new AutoFarm());
        MODULES.add(appleFarmer = new AppleFarmer());
        MODULES.add(sandFarmer = new SandFarmer());
        MODULES.add(noHurtCam = new NoHurtCam());
        MODULES.add(zoom = new Zoom());
        MODULES.add(timeChanger = new TimeChanger());
        MODULES.add(weatherChanger = new WeatherChanger());
        MODULES.add(keyStrokes = new KeyStrokes());
        MODULES.add(infoHud = new InfoHud());
        MODULES.add(armorHud = new ArmorHud());
        MODULES.add(targetHud = new TargetHud());
        MODULES.add(crosshair = new Crosshair());
        MODULES.add(storageEsp = new StorageEsp());
        MODULES.add(autoSprint = new AutoSprint());
        MODULES.add(autoTool = new AutoTool());
        MODULES.add(chestStealer = new ChestStealer());
        MODULES.add(autoRespawn = new AutoRespawn());
        MODULES.add(antiAFK = new AntiAFK());
        MODULES.add(sprintReset = new SprintReset());
        MODULES.add(xray = new XRay());
        MODULES.add(freecam = new Freecam());
        MODULES.add(friendManager = new FriendManager());
        MODULES.add(inventoryMove = new InventoryMove());
        MODULES.add(waypoints = new Waypoints());
        MODULES.add(aimAssist = new AimAssist());
        MODULES.add(autoCrystal = new AutoCrystal());
        MODULES.add(autoHitCrystal = new AutoHitCrystal());
        MODULES.add(shieldDisabler = new ShieldDisabler());
        MODULES.add(fasterXP = new FasterXP());
        MODULES.add(guiBind = new GuiBind());
        MODULES.add(panic = new Panic());
        MODULES.add(iface = new Interface());
        MODULES.add(hudList = new HudList());
    }

    public static List<Module> byCategory(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) if (m.category == c) out.add(m);
        return out;
    }

    public static Module byName(String name) {
        for (Module m : MODULES) if (m.name.equalsIgnoreCase(name)) return m;
        return null;
    }

    private static final List<Module> ENABLED_CACHE = new ArrayList<>();
    private static long enabledStamp = 0;
    private static int enabledHash = -1;

    /**
     * Список активных модулей для HUD. Пересобирается только когда реально
     * изменился набор включённых модулей (или раз в полсекунды из-за суффиксов),
     * а не каждый кадр — сортировка строк была заметной статьёй расхода.
     */
    public static List<Module> enabledSorted(MinecraftClient mc) {
        int hash = 1;
        for (Module m : MODULES) if (m.isEnabled()) hash = hash * 31 + m.name.hashCode();
        long now = System.currentTimeMillis();
        if (hash == enabledHash && now - enabledStamp < 500) return ENABLED_CACHE;
        enabledHash = hash;
        enabledStamp = now;
        ENABLED_CACHE.clear();
        for (Module m : MODULES) if (m.isEnabled() && m != hudList) ENABLED_CACHE.add(m);
        ENABLED_CACHE.sort(Comparator.comparingInt(
                (Module m) -> -mc.textRenderer.getWidth(m.name + m.hudSuffix())));
        return ENABLED_CACHE;
    }

    public static void onKey(int keyCode) {
        for (Module m : MODULES) if (m.key == keyCode) m.toggle();
    }

    public static void tick() {
        for (Module m : MODULES) if (m.isEnabled()) m.onTick();
    }
}
