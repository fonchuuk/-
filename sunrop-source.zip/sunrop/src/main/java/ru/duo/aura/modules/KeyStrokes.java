package ru.duo.aura.modules;

import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/** Экранные клавиши WASD + кнопки мыши и счётчик кликов. */
public class KeyStrokes extends Module {

    public final Setting.Num x = add(new Setting.Num("X", 8, 0, 600, 1));
    public final Setting.Num y = add(new Setting.Num("Y", 120, 0, 400, 1));
    public final Setting.Num size = add(new Setting.Num("Size", 16, 10, 28, 1));
    public final Setting.Bool mouse = add(new Setting.Bool("Mouse keys", true));
    public final Setting.Bool cps = add(new Setting.Bool("CPS", true));
    public final Setting.Bool space = add(new Setting.Bool("Space bar", true));

    public KeyStrokes() {
        super("KeyStrokes", "Показывает нажатия клавиш", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
    }
}
