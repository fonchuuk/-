package ru.duo.aura.modules;

import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.option.KeyBinding;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/** Позволяет ходить с открытым инвентарём или сундуком. */
public class InventoryMove extends Module {

    public final Setting.Bool inChat = add(new Setting.Bool("Also in chat", false));
    public final Setting.Bool allowJump = add(new Setting.Bool("Jump", true));
    public final Setting.Bool allowSneak = add(new Setting.Bool("Sneak", true));

    public InventoryMove() {
        super("InventoryMove", "Ходьба с открытым инвентарём", Category.OPTIMIZER, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.options == null) return;
        var screen = mc.currentScreen;
        boolean apply = screen instanceof HandledScreen<?>
                || (inChat.value && screen instanceof ChatScreen);
        if (!apply) return;

        var win = mc.getWindow();
        press(mc.options.forwardKey, win);
        press(mc.options.backKey, win);
        press(mc.options.leftKey, win);
        press(mc.options.rightKey, win);
        press(mc.options.sprintKey, win);
        if (allowJump.value) press(mc.options.jumpKey, win);
        if (allowSneak.value) press(mc.options.sneakKey, win);
    }

    private void press(KeyBinding key, net.minecraft.client.util.Window win) {
        int code = key.getDefaultKey().getCode();
        key.setPressed(InputUtil.isKeyPressed(win, code));
    }

    @Override
    public void onDisable() {
        if (mc.options == null) return;
        mc.options.forwardKey.setPressed(false);
        mc.options.backKey.setPressed(false);
        mc.options.leftKey.setPressed(false);
        mc.options.rightKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);
        mc.options.sneakKey.setPressed(false);
        mc.options.sprintKey.setPressed(false);
    }
}
