package ru.duo.aura;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Белый список серверов. Файл: .minecraft/config/sunrop-servers.txt
 * Одна строка = один адрес (можно без порта). Строки с # — комментарии.
 * Создаётся автоматически при первом запуске.
 */
public class ServerWhitelist {

    private static final List<String> ENTRIES = new ArrayList<>();
    private static Path file;
    private static long lastLoad = 0;

    public static Path path() {
        if (file == null) file = FabricLoader.getInstance().getConfigDir().resolve("sunrop-servers.txt");
        return file;
    }

    public static void load() {
        ENTRIES.clear();
        Path p = path();
        try {
            if (!Files.exists(p)) {
                Files.createDirectories(p.getParent());
                Files.writeString(p, """
                        # Sunrop - белый список серверов
                        # Сюда впиши адрес СВОЕГО сервера, по одному в строке.
                        # Порт можно не указывать. Регистр не важен. # - комментарий.
                        #
                        # Примеры:
                        # 26.14.88.3
                        # 26.14.88.3:25565
                        # myserver.ddns.net
                        # localhost
                        """);
            }
            for (String line : Files.readAllLines(p)) {
                String s = line.trim().toLowerCase(Locale.ROOT);
                if (s.isEmpty() || s.startsWith("#")) continue;
                ENTRIES.add(s);
            }
        } catch (IOException e) {
            System.err.println("[Sunrop] не смог прочитать " + p + ": " + e.getMessage());
        }
        lastLoad = System.currentTimeMillis();
    }

    /** Перечитывать файл не чаще раза в 3 секунды — можно править на лету. */
    public static void reloadIfStale() {
        if (System.currentTimeMillis() - lastLoad > 3000) load();
    }

    public static boolean matches(String address) {
        if (address == null) return false;
        String a = address.trim().toLowerCase(Locale.ROOT);
        String aNoPort = a.contains(":") ? a.substring(0, a.indexOf(':')) : a;
        for (String e : ENTRIES) {
            String eNoPort = e.contains(":") ? e.substring(0, e.indexOf(':')) : e;
            if (a.equals(e) || aNoPort.equals(eNoPort)) return true;
        }
        return false;
    }

    public static int size() {
        return ENTRIES.size();
    }
}
