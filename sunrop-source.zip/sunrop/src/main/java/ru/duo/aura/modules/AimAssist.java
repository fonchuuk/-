package ru.duo.aura.modules;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.RotationHelper;
import ru.duo.aura.core.Setting;

/**
 * Мягкий доводчик прицела: бьёшь сам, а камера чуть подтягивается к цели.
 * Это не аура — ударов он не делает.
 */
public class AimAssist extends Module {

    public final Setting.Num range = add(new Setting.Num("Range", 4.5, 2, 6, 0.1));
    public final Setting.Num fov = add(new Setting.Num("FOV", 60, 10, 180, 5));
    public final Setting.Mode mode = add(new Setting.Mode("Mode", 1, "SMOOTH", "FAST", "SNAP"));
    public final Setting.Num smoothness = add(new Setting.Num("Smoothness", 3, 1, 20, 1));
    public final Setting.Num maxStep = add(new Setting.Num("Max step", 25, 1, 90, 1));
    public final Setting.Num deadzone = add(new Setting.Num("Deadzone", 1.0, 0.0, 6.0, 0.5));
    public final Setting.Bool pitchToo = add(new Setting.Bool("Assist pitch", true));
    public final Setting.Bool onlyWhenClicking = add(new Setting.Bool("Only while clicking", true));
    public final Setting.Bool players = add(new Setting.Bool("Players", true));
    public final Setting.Bool mobs = add(new Setting.Bool("Mobs", true));

    public AimAssist() {
        super("AimAssist", "Мягко подводит прицел к цели", Category.SWORD, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null) return;
        if (onlyWhenClicking.value && !mc.options.attackKey.isPressed()) return;

        LivingEntity best = null;
        double bestAngle = fov.value / 2.0;

        double r = range.value;
        var self = p.getEntityPos();
        net.minecraft.util.math.Box box = new net.minecraft.util.math.Box(
                self.x - r, self.y - r, self.z - r, self.x + r, self.y + r, self.z + r);
        for (Entity e : mc.world.getOtherEntities(p, box)) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive()) continue;
            if (le instanceof PlayerEntity) {
                if (!players.value) continue;
                if (ru.duo.aura.core.ModuleManager.friendManager != null
                        && ru.duo.aura.core.ModuleManager.friendManager.isEnabled()
                        && ru.duo.aura.core.ModuleManager.friendManager.protectFromAura.value
                        && ru.duo.aura.core.Friends.is(le.getName().getString())) continue;
            } else if (!mobs.value) continue;

            if (p.distanceTo(le) > range.value) continue;
            float[] want = RotationHelper.angleTo(p, le);
            double diff = Math.abs(MathHelper.wrapDegrees(want[0] - p.getYaw()));
            if (diff < bestAngle) { bestAngle = diff; best = le; }
        }
        if (best == null) return;

        // чем больше Smoothness, тем меньшую долю оставшегося угла проходим за тик,
        // поэтому камера плавно подъезжает и замедляется у цели — без тряски
        float before = p.getPitch();

        if (mode.is("SNAP")) {
            // мгновенно наводимся прямо на цель
            float[] want = RotationHelper.angleTo(p, best);
            p.setYaw(want[0]);
            p.setPitch(pitchToo.value ? want[1] : before);
            return;
        }

        // доля оставшегося угла, которую проходим за тик:
        // FAST тянет заметно резче, SMOOTH — мягко подъезжает
        double div = mode.is("FAST") ? smoothness.value * 0.45 : smoothness.value * 1.1;
        float factor = (float) (1.0 / Math.max(1.0, div));
        if (factor > 0.95f) factor = 0.95f;
        RotationHelper.easeLook(p, best, factor, (float) maxStep.value, (float) deadzone.value);
        if (!pitchToo.value) p.setPitch(before);
    }
}
