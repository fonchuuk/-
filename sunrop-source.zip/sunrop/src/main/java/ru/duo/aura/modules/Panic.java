package ru.duo.aura.modules;

import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.ModuleManager;
import ru.duo.aura.core.Setting;

/**
 * Паника: по нажатию клавиши выключает все модули разом.
 * Сам сразу гаснет обратно — это кнопка, а не режим.
 */
public class Panic extends Module {

    public final Setting.Bool keepHud = add(new Setting.Bool("Keep HUD", false));
    public final Setting.Bool keepRender = add(new Setting.Bool("Keep visuals", false));
    public final Setting.Bool message = add(new Setting.Bool("Chat message", true));

    public Panic() {
        super("Panic", "Выключает все модули одной клавишей", Category.CLIENT, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onEnable() {
        int off = 0;
        for (Module m : ModuleManager.MODULES) {
            if (m == this) continue;
            if (m == ModuleManager.iface) continue;
            if (m == ModuleManager.guiBind) continue;                       // настройки клиента не трогаем
            if (keepHud.value && m == ModuleManager.hudList) continue;
            if (keepRender.value && m.category == Category.RENDER) continue;
            if (m.isEnabled()) { m.setEnabled(false); off++; }
        }

        if (message.value && mc.player != null) {
            mc.player.sendMessage(Text.literal("§7[Sunrop] §cПаника: выключено модулей — " + off), true);
        }

        // гасим сам модуль, чтобы его можно было нажать снова
        setEnabled(false);
    }
}
