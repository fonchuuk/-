package ru.duo.aura.gui;

import java.util.HashMap;
import java.util.Map;

/** Плавные переходы по ключу: значение догоняет цель с учётом времени кадра. */
public class Anim {

    private static final Map<String, Float> VALUES = new HashMap<>();
    private static long last = System.nanoTime();
    private static float dt = 0.016f;

    /** Вызывать один раз в начале кадра. */
    public static void frame() {
        long now = System.nanoTime();
        dt = Math.min(0.1f, (now - last) / 1_000_000_000f);
        last = now;
    }

    public static float dt() { return dt; }

    /** Экспоненциальное приближение к цели. speed — чем больше, тем быстрее. */
    public static float to(String key, float target, float speed) {
        float cur = VALUES.getOrDefault(key, target);
        float k = 1f - (float) Math.exp(-speed * dt);
        float next = cur + (target - cur) * k;
        if (Math.abs(target - next) < 0.001f) next = target;
        VALUES.put(key, next);
        return next;
    }

    public static float get(String key, float def) { return VALUES.getOrDefault(key, def); }

    public static void set(String key, float v) { VALUES.put(key, v); }

    public static void clear() { VALUES.clear(); }

    /** Сглаживание: плавный старт и остановка. */
    public static float ease(float t) {
        t = Math.max(0f, Math.min(1f, t));
        return t * t * (3f - 2f * t);
    }
}
