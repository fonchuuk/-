package ru.duo.aura.modules;

import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/** Убирает дождь и грозу локально — чище картинка и выше ФПС. */
public class WeatherChanger extends Module {

    public final Setting.Mode mode = add(new Setting.Mode("Weather", 0, "CLEAR", "RAIN", "THUNDER"));

    public WeatherChanger() {
        super("WeatherChanger", "Своя погода на клиенте", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onTick() {
        if (mc.world == null) return;
        switch (mode.get()) {
            case "RAIN" -> { mc.world.setRainGradient(1f); mc.world.setThunderGradient(0f); }
            case "THUNDER" -> { mc.world.setRainGradient(1f); mc.world.setThunderGradient(1f); }
            default -> { mc.world.setRainGradient(0f); mc.world.setThunderGradient(0f); }
        }
    }

    @Override
    public String hudSuffix() { return " §7[" + mode.get() + "]"; }
}
