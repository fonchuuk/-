package ru.duo.aura.modules;

import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ShulkerBoxScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/** Вытаскивает содержимое сундука одним открытием. */
public class ChestStealer extends Module {

    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 2, 0, 20, 1));
    public final Setting.Bool closeWhenDone = add(new Setting.Bool("Close when done", true));
    public final Setting.Bool shulkers = add(new Setting.Bool("Shulker boxes", true));

    private int timer;

    public ChestStealer() {
        super("ChestStealer", "Опустошает сундук автоматически", Category.OPTIMIZER, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null) return;
        if (!(mc.currentScreen instanceof HandledScreen<?> screen)) { timer = 0; return; }

        ScreenHandler handler = screen.getScreenHandler();
        int containerSlots;
        if (handler instanceof GenericContainerScreenHandler gch) containerSlots = gch.getRows() * 9;
        else if (handler instanceof ShulkerBoxScreenHandler && shulkers.value) containerSlots = 27;
        else return;

        if (timer > 0) { timer--; return; }

        for (int i = 0; i < containerSlots && i < handler.slots.size(); i++) {
            Slot slot = handler.getSlot(i);
            if (slot.getStack().isEmpty()) continue;
            mc.interactionManager.clickSlot(handler.syncId, i, 0, SlotActionType.QUICK_MOVE, mc.player);
            timer = delay.asInt();
            return;
        }

        if (closeWhenDone.value) mc.player.closeHandledScreen();
    }
}
