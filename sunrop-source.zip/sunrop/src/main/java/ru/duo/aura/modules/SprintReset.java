package ru.duo.aura.modules;

import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/** W-tap: сбрасывает спринт в момент удара — больше отдача по врагу. */
public class SprintReset extends Module {

    public final Setting.Num ticksOff = add(new Setting.Num("Off ticks", 2, 1, 6, 1));

    private boolean lastAttack;
    private int off;

    public SprintReset() {
        super("SprintReset", "W-tap для усиления ударов", Category.SWORD, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null) return;

        boolean attacking = mc.options.attackKey.isPressed()
                || (ru.duo.aura.core.ModuleManager.killAura != null
                    && ru.duo.aura.core.ModuleManager.killAura.isEnabled()
                    && ru.duo.aura.core.ModuleManager.killAura.current != null);

        if (attacking && !lastAttack) off = ticksOff.asInt();
        lastAttack = attacking;

        if (off > 0) { off--; p.setSprinting(false); }
    }
}
