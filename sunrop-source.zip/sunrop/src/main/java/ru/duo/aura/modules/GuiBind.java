package ru.duo.aura.modules;

import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/**
 * Клавиша открытия ClickGUI. Это не режим, а бинд: нажал — открылось окно,
 * модуль сразу гаснет обратно. Клавиша меняется в карточке «Клавиша».
 */
public class GuiBind extends Module {

    public final Setting.Bool hudEditor = add(new Setting.Bool("Open HUD editor instead", false));

    public GuiBind() {
        super("ClickGUI", "Клавиша открытия меню клиента", Category.CLIENT, GLFW.GLFW_KEY_GRAVE_ACCENT);
    }

    @Override
    public void onEnable() {
        if (mc != null) {
            mc.setScreen(hudEditor.value
                    ? new ru.duo.aura.gui.HudEditor()
                    : new ru.duo.aura.gui.ClickGui());
        }
        setEnabled(false);
    }
}
