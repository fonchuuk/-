package ru.duo.aura.modules;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.CritHelper;
import ru.duo.aura.core.Friends;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.ModuleManager;
import ru.duo.aura.core.RotationHelper;
import ru.duo.aura.core.Setting;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Боевая аура.
 *
 * Дистанция считается от глаз до ближайшей точки хитбокса — как в ваниле,
 * а не между центрами сущностей. Цели ищутся выборкой по коробке радиуса,
 * а не обходом всего мира. Залипание на цели и смена цели разведены:
 * «липкость» держит текущую, пока она валидна, а Switch delay не даёт
 * метаться между равнозначными целями.
 */
public class KillAura extends Module {

    // --- дистанция и ритм ---
    public final Setting.Num reach = add(new Setting.Num("Reach", 3.0, 2.0, 6.0, 0.1));
    public final Setting.Num wallReach = add(new Setting.Num("Wall reach", 3.0, 0.0, 6.0, 0.1));
    public final Setting.Num targets = add(new Setting.Num("Targets", 1, 1, 8, 1));
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 0, 0, 20, 1));
    public final Setting.Num jitter = add(new Setting.Num("Delay jitter", 0, 0, 6, 1));

    // --- удары ---
    public final Setting.Mode crits = add(new Setting.Mode("Crits", 2, "OFF", "WAIT", "JUMP"));
    public final Setting.Bool unsprint = add(new Setting.Bool("Unsprint", true));
    public final Setting.Bool cooldown = add(new Setting.Bool("Vanilla cooldown", true));
    public final Setting.Num minCooldown = add(new Setting.Num("Min charge", 1.0, 0.3, 1.0, 0.05));

    // --- поворот камеры ---
    public final Setting.Mode rotations = add(new Setting.Mode("Rotations", 1, "OFF", "SILENT", "SMOOTH", "SNAP"));
    public final Setting.Num rotSpeed = add(new Setting.Num("Rot speed", 18, 2, 180, 1));
    public final Setting.Num aimTolerance = add(new Setting.Num("Aim tolerance", 12, 2, 60, 1));
    public final Setting.Bool aimCheck = add(new Setting.Bool("Hit only when aimed", true));

    // --- выбор цели ---
    public final Setting.Bool lockTarget = add(new Setting.Bool("Lock target", true));
    public final Setting.Num switchDelay = add(new Setting.Num("Switch delay", 10, 0, 60, 1));
    public final Setting.Mode sort = add(new Setting.Mode("Sort", 0, "DISTANCE", "HEALTH", "ANGLE"));
    public final Setting.Bool scrollSwitch = add(new Setting.Bool("Scroll switch", false));

    // --- кого бить ---
    public final Setting.Bool mobs = add(new Setting.Bool("Mobs", true));
    public final Setting.Bool animals = add(new Setting.Bool("Animals", false));
    public final Setting.Bool players = add(new Setting.Bool("Players", false));
    public final Setting.Bool invisibles = add(new Setting.Bool("Invisible targets", false));
    public final Setting.Bool armorStands = add(new Setting.Bool("Armor stands", false));
    public final Setting.Bool throughWalls = add(new Setting.Bool("Through walls", false));

    // --- когда молчать ---
    public final Setting.Bool pauseInGui = add(new Setting.Bool("Pause in GUI", true));
    public final Setting.Bool pauseUsingItem = add(new Setting.Bool("Pause while using item", true));
    public final Setting.Mode weapon = add(new Setting.Mode("Weapon only", 0,
            "ANY", "SWORD", "SWORD+AXE", "ANY WEAPON"));

    private int timer = 0;
    private int sinceSwitch = 0;
    private final Random rnd = new Random();
    private final List<LivingEntity> found = new ArrayList<>();
    private LivingEntity pinned = null;

    public LivingEntity current;

    public KillAura() {
        super("KillAura", "Автоматически атакует цели вокруг", Category.SWORD, GLFW.GLFW_KEY_R);
    }

    @Override
    public String hudSuffix() {
        String s = crits.is("OFF") ? "" : " §7[" + crits.get() + "]";
        if (current != null) s += " §8" + current.getName().getString();
        return s;
    }

    @Override
    public void onDisable() {
        current = null;
        pinned = null;
        sinceSwitch = 0;
        timer = 0;
        found.clear();
        ru.duo.aura.core.TargetTracker.clear("KillAura");
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) return;
        if (p.isSpectator() || !p.isAlive()) { current = null; return; }

        // паузы
        if (pauseInGui.value && mc.currentScreen != null
                && !(mc.currentScreen instanceof net.minecraft.client.gui.screen.ChatScreen)) {
            current = null;
            return;
        }
        if (pauseUsingItem.value && p.isUsingItem()) return;
        if (!weaponOk(p)) { current = null; return; }

        collectTargets(p);
        if (found.isEmpty()) {
            current = null;
            sinceSwitch = 0;
            return;
        }

        current = pickTarget(p);
        if (current == null) return;
        ru.duo.aura.core.TargetTracker.set(current, "KillAura");

        rotate(p, current);

        if (timer > 0) { timer--; return; }
        if (cooldown.value && p.getAttackCooldownProgress(0.0f) < minCooldown.value) return;

        boolean needAim = aimCheck.value && (rotations.is("SMOOTH") || rotations.is("SNAP"));
        if (needAim && !RotationHelper.aimedAt(p, current, (float) aimTolerance.value)) return;

        if (!CritHelper.prepare(p, crits.get(), unsprint.value)) return;

        int max = Math.max(1, targets.asInt());
        if (max == 1) {
            hit(p, current);
        } else {
            int done = 0;
            // при мульти-таргете первой всегда идёт текущая цель
            hit(p, current);
            done++;
            for (LivingEntity e : found) {
                if (done >= max) break;
                if (e == current) continue;
                if (!inReach(p, e)) continue;
                hit(p, e);
                done++;
            }
        }

        timer = delay.asInt();
        if (jitter.asInt() > 0) timer += rnd.nextInt(jitter.asInt() + 1);
    }

    /**
     * Колесо мыши: ручное переключение цели. Возвращает true, если прокрутка
     * «съедена» клиентом и не должна менять слот в хотбаре.
     */
    public boolean onScroll(double dir) {
        if (!isEnabled() || !scrollSwitch.value) return false;
        if (mc.player == null || mc.currentScreen != null) return false;
        if (found.size() < 2) {
            // одна цель — просто фиксируем её, но прокрутку не забираем
            return false;
        }
        int idx = found.indexOf(current);
        if (idx < 0) idx = 0;
        idx = Math.floorMod(idx + (dir > 0 ? -1 : 1), found.size());
        pinned = found.get(idx);
        current = pinned;
        sinceSwitch = 0;
        ru.duo.aura.core.TargetTracker.set(current, "KillAura");
        return true;
    }

    /** Текущая цель закреплена вручную колесом. */
    public boolean isPinned() { return pinned != null && pinned == current; }

    private void hit(ClientPlayerEntity p, LivingEntity e) {
        mc.interactionManager.attackEntity(p, e);
        p.swingHand(Hand.MAIN_HAND);
    }

    // ------------------------------------------------------------- поворот

    private void rotate(ClientPlayerEntity p, LivingEntity target) {
        if (rotations.is("OFF")) return;
        if (rotations.is("SILENT")) {
            RotationHelper.silentLook(p, target);
        } else if (rotations.is("SNAP")) {
            RotationHelper.smoothLook(p, target, 180f);
        } else {
            // плавный доворот с замедлением у цели — без тряски камеры
            float factor = (float) Math.min(0.9, rotSpeed.value / 60.0);
            RotationHelper.easeLook(p, target, factor, (float) rotSpeed.value, 0.4f);
        }
    }

    // -------------------------------------------------------- выбор цели

    /** Держимся за текущую цель, пока она валидна; иначе меняем с задержкой. */
    private LivingEntity pickTarget(ClientPlayerEntity p) {
        sinceSwitch++;

        if (pinned != null) {
            if (stillValid(p, pinned) && found.contains(pinned)) {
                current = pinned;
                return current;
            }
            pinned = null;
        }

        boolean curOk = current != null && stillValid(p, current);
        if (!curOk) current = null;

        LivingEntity best = found.get(0);

        if (current == null) {
            sinceSwitch = 0;
            return best;
        }
        if (lockTarget.value) return current;                  // липнем, пока валидна
        if (best == current) return current;
        if (sinceSwitch < switchDelay.asInt()) return current;  // не мечемся

        sinceSwitch = 0;
        return best;
    }

    private boolean stillValid(ClientPlayerEntity p, LivingEntity e) {
        if (!e.isAlive() || e.isRemoved()) return false;
        // запас, чтобы цель не срывалась ровно на границе радиуса
        if (distanceToBox(p, e) > reach.value + 0.75) return false;
        if (!throughWalls.value && !p.canSee(e) && wallReach.value <= 0) return false;
        return wanted(e, p);
    }

    // --------------------------------------------------------- поиск целей

    private void collectTargets(ClientPlayerEntity p) {
        found.clear();
        double r = reach.value + 1.0;
        Vec3d self = p.getEntityPos();
        Box box = new Box(self.x - r, self.y - r, self.z - r, self.x + r, self.y + r, self.z + r);

        for (Entity e : mc.world.getOtherEntities(p, box)) {
            if (!(e instanceof LivingEntity le)) continue;
            if (!le.isAlive() || le.isRemoved()) continue;
            if (!invisibles.value && le.isInvisible()) continue;
            if (le instanceof ArmorStandEntity && !armorStands.value) continue;
            if (!wanted(le, p)) continue;
            if (!inReach(p, le)) continue;
            found.add(le);
        }

        switch (sort.get()) {
            case "HEALTH" -> found.sort((a, b) -> Float.compare(a.getHealth(), b.getHealth()));
            case "ANGLE" -> found.sort((a, b) -> Double.compare(angleDiff(p, a), angleDiff(p, b)));
            default -> found.sort((a, b) ->
                    Double.compare(distanceToBox(p, a), distanceToBox(p, b)));
        }
    }

    /** В пределах досягаемости с учётом стен и отдельного радиуса сквозь блоки. */
    private boolean inReach(ClientPlayerEntity p, LivingEntity e) {
        double d = distanceToBox(p, e);
        boolean visible = throughWalls.value || p.canSee(e);
        double limit = visible ? reach.value : Math.min(reach.value, wallReach.value);
        if (limit <= 0) return false;
        return d <= limit;
    }

    /** Расстояние от глаз до ближайшей точки хитбокса — как считает ванила. */
    private static double distanceToBox(ClientPlayerEntity p, Entity e) {
        Vec3d eye = p.getEyePos();
        Box b = e.getBoundingBox();
        double dx = Math.max(Math.max(b.minX - eye.x, 0.0), eye.x - b.maxX);
        double dy = Math.max(Math.max(b.minY - eye.y, 0.0), eye.y - b.maxY);
        double dz = Math.max(Math.max(b.minZ - eye.z, 0.0), eye.z - b.maxZ);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    // ------------------------------------------------------------- фильтры

    private boolean wanted(LivingEntity e, ClientPlayerEntity self) {
        if (e instanceof PlayerEntity pl) {
            if (ModuleManager.friendManager != null
                    && ModuleManager.friendManager.isEnabled()
                    && ModuleManager.friendManager.protectFromAura.value
                    && Friends.is(pl.getName().getString())) return false;
            if (self.isTeammate(pl)) return false;
            return players.value;
        }
        if (e instanceof ArmorStandEntity) return armorStands.value;
        if (e instanceof Monster) return mobs.value;
        if (e instanceof AnimalEntity) return animals.value;
        return mobs.value;
    }

    private boolean weaponOk(ClientPlayerEntity p) {
        var stack = p.getMainHandStack();
        if (weapon.is("ANY")) return true;
        if (stack.isEmpty()) return false;
        boolean sword = stack.isIn(net.minecraft.registry.tag.ItemTags.SWORDS);
        boolean axe = stack.isIn(net.minecraft.registry.tag.ItemTags.AXES);
        boolean other = stack.isOf(net.minecraft.item.Items.TRIDENT)
                || stack.isOf(net.minecraft.item.Items.MACE);
        return switch (weapon.get()) {
            case "SWORD" -> sword;
            case "SWORD+AXE" -> sword || axe;
            case "ANY WEAPON" -> sword || axe || other;
            default -> true;
        };
    }

    private static double angleDiff(ClientPlayerEntity p, Entity t) {
        Vec3d d = t.getBoundingBox().getCenter().subtract(p.getEyePos());
        float yaw = (float) (MathHelper.atan2(d.z, d.x) * (180.0 / Math.PI)) - 90.0f;
        return Math.abs(MathHelper.wrapDegrees(yaw - p.getYaw()));
    }
}
