package ru.duo.aura.modules;

import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/** Убирает «качание» камеры и красную вспышку при получении урона. */
public class NoHurtCam extends Module {

    public final Setting.Bool shake = add(new Setting.Bool("No shake", true));

    public NoHurtCam() {
        super("NoHurtCam", "Камера не дёргается от урона", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (shake.value && mc.player.hurtTime > 0) mc.player.hurtTime = 0;
    }
}
