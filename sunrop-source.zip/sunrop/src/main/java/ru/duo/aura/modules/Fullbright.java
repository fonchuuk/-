package ru.duo.aura.modules;

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/**
 * Яркость. GAMMA часто зажимается настройками игры, поэтому по умолчанию
 * используется локальный эффект ночного зрения — он работает всегда.
 */
public class Fullbright extends Module {

    public final Setting.Mode mode = add(new Setting.Mode("Mode", 0, "NIGHTVISION", "GAMMA", "BOTH"));
    public final Setting.Num gamma = add(new Setting.Num("Gamma", 15, 1, 20, 1));

    private double saved = -1;

    public Fullbright() {
        super("Fullbright", "Полная яркость мира", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public String hudSuffix() {
        return " §7[" + mode.get() + "]";
    }

    @Override
    public void onEnable() {
        if (mc.options != null && saved < 0) saved = mc.options.getGamma().getValue();
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;

        if (!mode.is("NIGHTVISION") && mc.options != null) {
            double want = gamma.value;
            if (mc.options.getGamma().getValue() < want) {
                mc.options.getGamma().setValue(want);
            }
        }

        if (!mode.is("GAMMA")) {
            // короткий эффект, продлеваем каждый тик — мерцания нет
            mc.player.addStatusEffect(new StatusEffectInstance(
                    StatusEffects.NIGHT_VISION, 300, 0, false, false, false));
        }
    }

    @Override
    public void onDisable() {
        if (mc.options != null && saved >= 0) {
            mc.options.getGamma().setValue(saved);
            saved = -1;
        }
        if (mc.player != null) {
            mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }
}
