package ru.duo.aura.core;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Плавный доворот камеры: без рывков и тряски. */
public class RotationHelper {

    /** Куда надо смотреть, чтобы попасть по цели: [yaw, pitch]. */
    public static float[] angleTo(ClientPlayerEntity p, Entity target) {
        Vec3d eye = p.getEyePos();
        Vec3d to = target.getBoundingBox().getCenter();
        double dx = to.x - eye.x, dy = to.y - eye.y, dz = to.z - eye.z;
        double flat = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (MathHelper.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;
        float pitch = (float) (-(MathHelper.atan2(dy, flat) * (180.0 / Math.PI)));
        return new float[]{yaw, MathHelper.clamp(pitch, -90f, 90f)};
    }

    /**
     * Доворачивает камеру к цели не более чем на maxStep градусов за тик.
     * @param maxStep 180 = мгновенно (старое поведение), 10-25 = плавно
     */
    public static void smoothLook(ClientPlayerEntity p, Entity target, float maxStep) {
        float[] want = angleTo(p, target);
        p.setYaw(approach(p.getYaw(), want[0], maxStep));
        p.setPitch(MathHelper.clamp(approach(p.getPitch(), want[1], maxStep), -90f, 90f));
    }

    /**
     * Плавное доведение с замедлением у цели: шаг зависит от оставшегося угла,
     * поэтому камера не дёргается рывками по maxStep, а приезжает мягко.
     *
     * @param factor   доля оставшегося угла за тик (0.05–0.5)
     * @param maxStep  потолок градусов за тик
     * @param deadzone ближе этого угла камера не трогается вовсе
     */
    public static void easeLook(ClientPlayerEntity p, Entity target,
                                float factor, float maxStep, float deadzone) {
        float[] want = angleTo(p, target);
        float dYaw = MathHelper.wrapDegrees(want[0] - p.getYaw());
        float dPitch = MathHelper.wrapDegrees(want[1] - p.getPitch());

        if (Math.abs(dYaw) < deadzone && Math.abs(dPitch) < deadzone) return;

        float stepYaw = clampStep(dYaw * factor, maxStep);
        float stepPitch = clampStep(dPitch * factor * 0.8f, maxStep * 0.8f);

        // не перескакиваем цель
        if (Math.abs(stepYaw) > Math.abs(dYaw)) stepYaw = dYaw;
        if (Math.abs(stepPitch) > Math.abs(dPitch)) stepPitch = dPitch;

        p.setYaw(p.getYaw() + stepYaw);
        p.setPitch(MathHelper.clamp(p.getPitch() + stepPitch, -90f, 90f));
    }

    private static float clampStep(float v, float max) {
        return Math.max(-max, Math.min(max, v));
    }

    /**
     * «Тихий» доворот: камера игрока НЕ трогается вообще, серверу просто
     * отправляется пакет с нужным углом. Монитор не трясёт, удары засчитываются.
     */
    public static void silentLook(ClientPlayerEntity p, Entity target) {
        float[] want = angleTo(p, target);
        if (p.networkHandler == null) return;
        p.networkHandler.sendPacket(new net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket.LookAndOnGround(
                want[0], MathHelper.clamp(want[1], -90f, 90f),
                p.isOnGround(), p.horizontalCollision));
    }

    /** Уже смотрим на цель достаточно точно? */
    public static boolean aimedAt(ClientPlayerEntity p, Entity target, float toleranceDeg) {
        float[] want = angleTo(p, target);
        float dy = Math.abs(MathHelper.wrapDegrees(want[0] - p.getYaw()));
        float dp = Math.abs(want[1] - p.getPitch());
        return dy <= toleranceDeg && dp <= toleranceDeg;
    }

    private static float approach(float current, float target, float maxStep) {
        float diff = MathHelper.wrapDegrees(target - current);
        if (Math.abs(diff) <= maxStep) return current + diff;
        return current + Math.signum(diff) * maxStep;
    }
}
