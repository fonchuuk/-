package ru.duo.aura.core;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/**
 * База для фарм-модулей: поиск блока, подход к нему пешком и непрерывное ломание.
 *
 * Важно: updateBlockBreakingProgress нужно звать КАЖДЫЙ тик по одной и той же позиции,
 * иначе прогресс разрушения сбрасывается и блок никогда не ломается.
 */
public abstract class FarmModule extends Module {

    public final Setting.Num radius = add(new Setting.Num("Radius", 6, 1, 24, 1));
    public final Setting.Num vertical = add(new Setting.Num("Height", 4, 0, 12, 1));
    public final Setting.Bool walk = add(new Setting.Bool("Auto walk", true));
    public final Setting.Bool rotate = add(new Setting.Bool("Rotate", true));

    protected BlockPos target;
    protected boolean walking = false;

    protected FarmModule(String name, String desc, Category cat, int key) {
        super(name, desc, cat, key);
    }

    /** Подходит ли блок для фарма. */
    protected abstract boolean matches(BlockPos pos);

    /** Вызывается перед ломанием (например, выбрать инструмент). */
    protected void beforeBreak(BlockPos pos) {}

    /** Нечего ломать — можно сделать что-то ещё (посадить и т.п.). */
    protected void idle() {}

    @Override
    public void onDisable() {
        stopWalking();
        target = null;
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null) { stopWalking(); return; }

        // цель ещё актуальна?
        if (target != null && !matches(target)) target = null;

        if (target == null) {
            List<BlockPos> found = BlockBreaker.find(mc, radius.asInt(), vertical.asInt(),
                    this::matches, 1000.0);
            target = found.isEmpty() ? null : found.get(0);
        }

        if (target == null) {
            stopWalking();
            idle();
            return;
        }

        double dist = p.getEyePos().distanceTo(Vec3d.ofCenter(target));

        if (dist > 4.3) {
            if (walk.value) walkTo(p, target);
            else { stopWalking(); target = null; }
            return;
        }

        stopWalking();
        beforeBreak(target);
        if (rotate.value) BlockBreaker.lookAtBlock(p, target);

        // каждый тик — иначе прогресс сбросится
        BlockBreaker.breakBlock(mc, target, false);
        p.swingHand(Hand.MAIN_HAND);
    }

    /** Простая ходьба: смотрим на цель и жмём «вперёд», прыгаем если упёрлись. */
    protected void walkTo(ClientPlayerEntity p, BlockPos pos) {
        Vec3d to = Vec3d.ofCenter(pos);
        double dx = to.x - p.getX(), dz = to.z - p.getZ();
        float yaw = (float) (Math.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;
        p.setYaw(yaw);
        if (rotate.value) BlockBreaker.lookAtBlock(p, pos);

        mc.options.forwardKey.setPressed(true);
        walking = true;

        // застряли или надо подняться
        if (p.horizontalCollision && p.isOnGround()) {
            p.jump();
        }
        // цель заметно выше — подпрыгиваем
        if (to.y > p.getY() + 1.2 && p.isOnGround() && p.horizontalCollision) {
            p.jump();
        }
    }

    protected void stopWalking() {
        if (walking) {
            mc.options.forwardKey.setPressed(false);
            walking = false;
        }
    }
}
