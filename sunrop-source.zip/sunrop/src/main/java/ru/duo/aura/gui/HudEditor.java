package ru.duo.aura.gui;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.ConfigFile;
import ru.duo.aura.core.HudLayout;
import ru.duo.aura.core.Theme;

/** Редактор HUD: элементы двигаются мышью. */
public class HudEditor extends Screen {

    private HudLayout.Element dragging;
    private int dragX, dragY;
    private boolean snap = true;

    public HudEditor() {
        super(Text.literal("Sunrop HUD"));
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, this.width, this.height, 0x99070810);

        int accent = Theme.accent();

        // сетка
        if (snap) {
            for (int x = 0; x < this.width; x += 20) ctx.fill(x, 0, x + 1, this.height, 0x11FFFFFF);
            for (int y = 0; y < this.height; y += 20) ctx.fill(0, y, this.width, y + 1, 0x11FFFFFF);
        }
        // центральные направляющие
        ctx.fill(this.width / 2, 0, this.width / 2 + 1, this.height, 0x22FFFFFF);
        ctx.fill(0, this.height / 2, this.width, this.height / 2 + 1, 0x22FFFFFF);

        // подсказка
        String hint = "Перетащи блоки мышью  ·  ПКМ по блоку — вернуть на место  ·  G — сетка  ·  R — сброс всего  ·  Esc — выйти";
        int hw = this.textRenderer.getWidth(hint) + 16;
        int hx = this.width / 2 - hw / 2;
        Draw.round(ctx, hx, 8, hx + hw, 28, 5, Theme.alpha(Theme.panel(), 235));
        Draw.round(ctx, hx, 8, hx + 2, 28, 1, accent);
        ctx.drawText(this.textRenderer, hint, hx + 9, 14, Theme.text(), false);

        for (HudLayout.Element e : HudLayout.all()) {
            int w = Math.max(44, e.w), h = Math.max(12, e.h);
            boolean hot = dragging == e
                    || (mouseX >= e.x && mouseX <= e.x + w && mouseY >= e.y && mouseY <= e.y + h);

            Draw.round(ctx, e.x, e.y, e.x + w, e.y + h, 3,
                    hot ? Theme.alpha(accent, 120) : Theme.alpha(Theme.panel(), 200));
            outline(ctx, e.x, e.y, e.x + w, e.y + h, hot ? accent : Theme.border());

            String t = e.title;
            if (this.textRenderer.getWidth(t) > w - 6) t = this.textRenderer.trimToWidth(t, w - 8) + "…";
            ctx.drawText(this.textRenderer, t, e.x + 3, e.y + h / 2 - 4, 0xFFFFFFFF, false);

            if (hot) {
                String pos = e.x + ", " + e.y;
                ctx.drawText(this.textRenderer, pos, e.x, e.y - 10, Theme.textDim(), false);
            }
        }
    }

    private void outline(DrawContext ctx, int x1, int y1, int x2, int y2, int c) {
        ctx.fill(x1, y1, x2, y1 + 1, c);
        ctx.fill(x1, y2 - 1, x2, y2, c);
        ctx.fill(x1, y1, x1 + 1, y2, c);
        ctx.fill(x2 - 1, y1, x2, y2, c);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        var list = HudLayout.all();
        for (int i = list.size() - 1; i >= 0; i--) {
            HudLayout.Element e = list.get(i);
            int w = Math.max(44, e.w), h = Math.max(12, e.h);
            if (mx < e.x || mx > e.x + w || my < e.y || my > e.y + h) continue;

            if (click.button() == 1) {
                e.x = Math.max(0, e.defX);
                e.y = Math.max(0, e.defY);
                return true;
            }
            dragging = e;
            dragX = (int) (mx - e.x);
            dragY = (int) (my - e.y);
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (dragging != null) {
            int nx = (int) (click.x() - dragX);
            int ny = (int) (click.y() - dragY);
            if (snap) { nx = Math.round(nx / 2f) * 2; ny = Math.round(ny / 2f) * 2; }
            dragging.x = nx;
            dragging.y = ny;
            HudLayout.clamp(this.width, this.height);
            return true;
        }
        return super.mouseDragged(click, dx, dy);
    }

    @Override
    public boolean mouseReleased(Click click) {
        dragging = null;
        return super.mouseReleased(click);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (input.key() == GLFW.GLFW_KEY_G) { snap = !snap; return true; }
        if (input.key() == GLFW.GLFW_KEY_R) { HudLayout.reset(); return true; }
        return super.keyPressed(input);
    }

    @Override
    public void close() {
        HudLayout.clamp(this.width, this.height);
        ConfigFile.save();
        super.close();
    }
}
