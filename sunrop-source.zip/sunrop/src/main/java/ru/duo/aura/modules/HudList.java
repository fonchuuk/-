package ru.duo.aura.modules;

import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/** Настройки HUD: ватермарка, список активных модулей, инфо о цели. */
public class HudList extends Module {

    public final Setting.Bool watermark = add(new Setting.Bool("Watermark", true));
    public final Setting.Bool logo = add(new Setting.Bool("Logo in watermark", true));
    public final Setting.Num logoSize = add(new Setting.Num("Logo size", 14, 8, 32, 1));
    public final Setting.Bool arrayList = add(new Setting.Bool("ArrayList", true));
    public final Setting.Bool targetInfo = add(new Setting.Bool("Target info", true));
    public final Setting.Bool coords = add(new Setting.Bool("Coords + FPS", true));
    public final Setting.Bool rainbow = add(new Setting.Bool("Rainbow", false));
    public final Setting.Mode style = add(new Setting.Mode("Style", 1, "CLASSIC", "SYSTEM"));
    public final Setting.Bool bottomLine = add(new Setting.Bool("Bottom line", true));

    public HudList() {
        super("HUD", "Интерфейс клиента на экране", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
        setEnabled(true);
    }
}
