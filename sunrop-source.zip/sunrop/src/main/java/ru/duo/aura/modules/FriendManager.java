package ru.duo.aura.modules;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Friends;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/**
 * Друзья: их не трогают аура и триггербот, в ESP они зелёные.
 * Список лежит в config/sunrop-friends.txt, добавить можно прицелившись
 * в игрока и нажав клавишу модуля с включённым Add by crosshair.
 */
public class FriendManager extends Module {

    public final Setting.Bool protectFromAura = add(new Setting.Bool("Protect from aura", true));
    public final Setting.Bool colorInEsp = add(new Setting.Bool("Green in ESP", true));
    public final Setting.Bool addByCrosshair = add(new Setting.Bool("Add by crosshair", true));

    public FriendManager() {
        super("Friends", "Список друзей, их не бьёт аура", Category.CLIENT, GLFW.GLFW_KEY_UNKNOWN);
        setEnabled(true);
    }

    @Override
    public void onEnable() {
        Friends.load();
        if (mc.player == null) return;

        if (addByCrosshair.value) {
            HitResult hit = mc.crosshairTarget;
            if (hit != null && hit.getType() == HitResult.Type.ENTITY) {
                Entity e = ((EntityHitResult) hit).getEntity();
                if (e instanceof PlayerEntity) {
                    String name = e.getName().getString();
                    boolean added = Friends.toggle(name);
                    mc.player.sendMessage(Text.literal(added
                            ? "§7[Sunrop] §aдруг добавлен: §f" + name
                            : "§7[Sunrop] §cдруг удалён: §f" + name), false);
                }
            }
        }
    }

    @Override
    public String hudSuffix() { return " §7[" + Friends.count() + "]"; }
}
