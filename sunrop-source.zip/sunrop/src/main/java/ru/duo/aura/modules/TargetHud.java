package ru.duo.aura.modules;

import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/** Карточка текущей цели (аура/триггер) и подсветка этой цели в мире. */
public class TargetHud extends Module {

    public final Setting.Bool healthBar = add(new Setting.Bool("Health bar", true));
    public final Setting.Bool distance = add(new Setting.Bool("Distance", true));
    public final Setting.Bool showSource = add(new Setting.Bool("Show source", true));
    public final Setting.Bool reactionBar = add(new Setting.Bool("Reaction bar", true));
    public final Setting.Bool marker = add(new Setting.Bool("Target marker", true));
    public final Setting.Mode markerMode = add(new Setting.Mode("Marker", 0, "BOX", "CORNERS", "GLOW"));
    public final Setting.Num offsetY = add(new Setting.Num("Offset Y", 36, 0, 200, 1));

    public TargetHud() {
        super("TargetHud", "Карточка и подсветка текущей цели", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
    }
}
