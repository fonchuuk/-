package ru.duo.aura;

import net.fabricmc.loader.api.FabricLoader;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.ModuleManager;
import ru.duo.aura.core.HudLayout;
import ru.duo.aura.core.Setting;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Сохранение модулей/настроек/биндов в .minecraft/config/sunrop.txt */
public class ConfigFile {

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("sunrop.txt");
    }

    public static void save() {
        List<String> lines = new ArrayList<>();
        lines.add("# Sunrop config — правится и руками, но проще через ClickGUI");
        for (Module m : ModuleManager.MODULES) {
            lines.add(m.name + ".enabled=" + m.isEnabled());
            lines.add(m.name + ".key=" + m.key);
            for (Setting s : m.settings) {
                lines.add(m.name + "." + s.name + "=" + s.serialize());
            }
        }
        lines.addAll(HudLayout.serialize());
        try {
            Files.createDirectories(path().getParent());
            Files.write(path(), lines);
        } catch (IOException e) {
            System.err.println("[Sunrop] не смог сохранить конфиг: " + e.getMessage());
        }
    }

    public static void load() {
        Path p = path();
        if (!Files.exists(p)) return;
        try {
            for (String line : Files.readAllLines(p)) {
                String s = line.trim();
                if (s.isEmpty() || s.startsWith("#")) continue;
                int eq = s.indexOf('=');
                int dot = s.indexOf('.');
                if (eq < 0 || dot < 0 || dot > eq) continue;

                String modName = s.substring(0, dot);
                String key = s.substring(dot + 1, eq);
                String value = s.substring(eq + 1);

                if (modName.equals("hud")) { HudLayout.deserialize(key, value); continue; }

                Module m = ModuleManager.byName(modName);
                if (m == null) continue;

                if (key.equals("enabled")) {
                    m.setEnabled(Boolean.parseBoolean(value));
                } else if (key.equals("key")) {
                    try {
                        int k = Integer.parseInt(value);
                        // миграция бинда: старый Right Shift у ClickGUI -> `
                        if (m == ru.duo.aura.core.ModuleManager.guiBind
                                && k == org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_SHIFT) {
                            k = org.lwjgl.glfw.GLFW.GLFW_KEY_GRAVE_ACCENT;
                        }
                        m.key = k;
                    } catch (NumberFormatException ignored) {}
                } else {
                    for (Setting st : m.settings) {
                        if (st.name.equals(key)) { st.deserialize(value); break; }
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("[Sunrop] не смог прочитать конфиг: " + e.getMessage());
        }
    }
}
