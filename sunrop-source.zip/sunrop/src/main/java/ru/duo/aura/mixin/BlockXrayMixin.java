package ru.duo.aura.mixin;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.Direction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.duo.aura.core.ModuleManager;
import ru.duo.aura.modules.XRay;

/**
 * XRay: решаем за игру, рисовать ли грань блока. Руды рисуем всегда,
 * остальное не рисуем вовсе — получается «прозрачный» мир.
 */
@Mixin(Block.class)
public class BlockXrayMixin {

    @Inject(method = "shouldDrawSide", at = @At("HEAD"), cancellable = true)
    private static void sunrop$xray(BlockState state, BlockState otherState, Direction side,
                                    CallbackInfoReturnable<Boolean> cir) {
        XRay x = ModuleManager.xray;
        if (x == null || !x.isEnabled()) return;
        cir.setReturnValue(x.shows(state));
    }
}
