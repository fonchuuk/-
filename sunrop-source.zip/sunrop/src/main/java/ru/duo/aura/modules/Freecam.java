package ru.duo.aura.modules;

import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/** Свободная камера: тело остаётся на месте, смотришь откуда хочешь. */
public class Freecam extends Module {

    public final Setting.Num speed = add(new Setting.Num("Speed", 0.7, 0.1, 3.0, 0.1));
    public final Setting.Bool noClip = add(new Setting.Bool("Through blocks", true));

    private ArmorStandEntity cam;
    private Vec3d start;

    public Freecam() {
        super("Freecam", "Свободная камера", Category.OPTIMIZER, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onEnable() {
        if (mc.player == null || mc.world == null) { setEnabled(false); return; }
        start = mc.player.getEntityPos();
        cam = new ArmorStandEntity(mc.world, start.x, start.y, start.z);
        cam.setInvisible(true);
        cam.setNoGravity(true);
        cam.noClip = noClip.value;
        cam.setYaw(mc.player.getYaw());
        cam.setPitch(mc.player.getPitch());
        cam.setHeadYaw(mc.player.getYaw());
        mc.world.addEntity(cam);
        mc.setCameraEntity(cam);
    }

    @Override
    public void onDisable() {
        if (mc.player != null) mc.setCameraEntity(mc.player);
        if (cam != null && mc.world != null) {
            cam.discard();
            cam = null;
        }
        start = null;
    }

    @Override
    public void onTick() {
        if (cam == null || mc.player == null) return;
        if (mc.currentScreen != null) return;

        cam.setYaw(mc.player.getYaw());
        cam.setPitch(mc.player.getPitch());
        cam.setHeadYaw(mc.player.getYaw());
        cam.noClip = noClip.value;

        double s = speed.value;
        double yawRad = Math.toRadians(cam.getYaw());
        double fx = -Math.sin(yawRad), fz = Math.cos(yawRad);

        double dx = 0, dy = 0, dz = 0;
        if (mc.options.forwardKey.isPressed()) { dx += fx * s; dz += fz * s; }
        if (mc.options.backKey.isPressed()) { dx -= fx * s; dz -= fz * s; }
        if (mc.options.leftKey.isPressed()) { dx += fz * s; dz -= fx * s; }
        if (mc.options.rightKey.isPressed()) { dx -= fz * s; dz += fx * s; }
        if (mc.options.jumpKey.isPressed()) dy += s;
        if (mc.options.sneakKey.isPressed()) dy -= s;

        // учитываем наклон камеры при движении вперёд
        if (mc.options.forwardKey.isPressed()) dy -= Math.sin(Math.toRadians(cam.getPitch())) * s;

        cam.setPosition(cam.getX() + dx, cam.getY() + dy, cam.getZ() + dz);
        cam.setVelocity(Vec3d.ZERO);

        // само тело стоит на месте
        mc.player.setVelocity(0, mc.player.getVelocity().y, 0);
        mc.options.forwardKey.setPressed(mc.options.forwardKey.isPressed());
    }

    @Override
    public String hudSuffix() {
        if (cam == null || start == null) return "";
        return " §7[" + (int) cam.getEntityPos().distanceTo(start) + "м]";
    }
}
