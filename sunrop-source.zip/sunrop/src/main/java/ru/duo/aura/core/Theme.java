package ru.duo.aura.core;

/** Цвета интерфейса: тёмная/светлая тема + акцент. */
public class Theme {

    public static boolean light = false;
    public static int accentIndex = 0;

    public static final String[] ACCENT_NAMES = {"BLUE", "PURPLE", "GREEN", "ORANGE", "PINK", "CYAN"};
    private static final int[] ACCENTS = {
            0xFF4D8DFF, 0xFF9B5CFF, 0xFF3FD17A, 0xFFFF9442, 0xFFFF5C9A, 0xFF35D0E0};

    public static int accent() {
        return ACCENTS[Math.floorMod(accentIndex, ACCENTS.length)];
    }

    public static int accentSoft() {
        return (accent() & 0x00FFFFFF) | 0x33000000;
    }

    public static int accentDim() {
        return mix(accent(), bg(), 0.55f);
    }

    /** фон окна */
    public static int bg() { return light ? 0xFFF2F3F7 : 0xFF14151C; }

    /** панели внутри окна */
    public static int panel() { return light ? 0xFFFFFFFF : 0xFF1B1D26; }

    /** строки/карточки */
    public static int card() { return light ? 0xFFEDEFF5 : 0xFF222531; }

    public static int cardHover() { return light ? 0xFFE2E6F0 : 0xFF2B2F3E; }

    public static int border() { return light ? 0xFFD8DCE6 : 0xFF2E3240; }

    public static int text() { return light ? 0xFF171922 : 0xFFF1F3F9; }

    public static int textDim() { return light ? 0xFF767C8C : 0xFF868C9E; }

    public static int shadow() { return 0x66000000; }

    public static int mix(int a, int b, float t) {
        int aa = (a >> 24) & 0xFF, ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int ba = (b >> 24) & 0xFF, br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        int r = (int) (ar + (br - ar) * t);
        int g = (int) (ag + (bg - ag) * t);
        int bl = (int) (ab + (bb - ab) * t);
        int al = (int) (aa + (ba - aa) * t);
        return (al << 24) | (r << 16) | (g << 8) | bl;
    }

    public static int alpha(int color, int a) {
        return (color & 0x00FFFFFF) | (a << 24);
    }
}
