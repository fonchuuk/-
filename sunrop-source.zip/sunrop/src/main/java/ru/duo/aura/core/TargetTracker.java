package ru.duo.aura.core;

import net.minecraft.entity.LivingEntity;

/** Общая «текущая цель» клиента: кто её выбрал и когда. */
public final class TargetTracker {

    private static LivingEntity target;
    private static String source = "";
    private static long stamp = 0;

    private TargetTracker() {}

    public static void set(LivingEntity e, String src) {
        target = e;
        source = src;
        stamp = System.currentTimeMillis();
    }

    public static void clear(String src) {
        if (src.equals(source)) { target = null; source = ""; }
    }

    /** Цель, если она ещё жива и обновлялась недавно. */
    public static LivingEntity get() {
        if (target == null) return null;
        if (!target.isAlive() || target.isRemoved()) { target = null; return null; }
        if (System.currentTimeMillis() - stamp > 600) { target = null; return null; }
        return target;
    }

    public static String source() { return get() == null ? "" : source; }
}
