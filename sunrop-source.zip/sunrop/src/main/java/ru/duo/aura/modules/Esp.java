package ru.duo.aura.modules;

import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/** Визуалы: рамки вокруг существ, трассеры, подсветка цели. */
public class Esp extends Module {

    public final Setting.Bool boxes = add(new Setting.Bool("Boxes", true));
    public final Setting.Mode boxMode = add(new Setting.Mode("Box mode", 0, "STATIC", "DYNAMIC"));
    public final Setting.Bool tracers = add(new Setting.Bool("Tracers", false));
    public final Setting.Num tracerWidth = add(new Setting.Num("Tracer width", 1, 1, 3, 1));
    public final Setting.Num tracerLimit = add(new Setting.Num("Max tracers", 12, 1, 40, 1));
    public final Setting.Bool targetGlow = add(new Setting.Bool("Target marker", true));
    public final Setting.Bool healthBar = add(new Setting.Bool("Health bar", true));
    public final Setting.Bool names = add(new Setting.Bool("Names", true));
    public final Setting.Num range = add(new Setting.Num("Range", 32, 8, 96, 1));
    public final Setting.Num maxEntities = add(new Setting.Num("Max entities", 48, 4, 150, 1));
    public final Setting.Bool mobs = add(new Setting.Bool("Mobs", true));
    public final Setting.Bool animals = add(new Setting.Bool("Animals", false));
    public final Setting.Bool players = add(new Setting.Bool("Players", true));
    public final Setting.Bool items = add(new Setting.Bool("Items", false));

    public Esp() {
        super("ESP", "Рамки и трассеры к существам", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
    }
}
