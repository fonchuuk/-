package ru.duo.aura;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.ModuleManager;
import ru.duo.aura.gui.ClickGui;
import ru.duo.aura.gui.HudRenderer;

import java.util.HashSet;
import java.util.Set;

public class DuoAuraClient implements ClientModInitializer {

    public static final KeyBinding.Category CATEGORY =
            KeyBinding.Category.create(Identifier.of("sunrop", "main"));

    private static KeyBinding keyGui;
    private static KeyBinding keyHud;
    private final Set<Integer> down = new HashSet<>();
    private boolean warned = false;
    private int autoSaveTick = 0;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        ConfigFile.load();
        if (ModuleManager.iface != null) ModuleManager.iface.apply();
        ServerWhitelist.load();
        ru.duo.aura.core.Friends.load();
        HudRenderer.register();

        keyGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.sunrop.gui", GLFW.GLFW_KEY_GRAVE_ACCENT, CATEGORY));
        keyHud = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.sunrop.hud", GLFW.GLFW_KEY_RIGHT_CONTROL, CATEGORY));

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(c -> ConfigFile.save());

        System.out.println("[Sunrop] загружен. ClickGUI: ` (настраивается). Белый список: "
                + ServerWhitelist.path());
    }

    private void onTick(MinecraftClient mc) {
        while (keyGui.wasPressed()) {
            mc.setScreen(new ClickGui());
        }
        while (keyHud.wasPressed()) {
            mc.setScreen(new ru.duo.aura.gui.HudEditor());
        }

        handleModuleBinds(mc);

        if (mc.player == null || mc.world == null) return;

        if (!allowed(mc)) {
            boolean any = false;
            for (Module m : ModuleManager.MODULES) {
                // визуальные модули чисто клиентские — их не трогаем нигде
                if (m.isEnabled() && m.category != ru.duo.aura.core.Category.RENDER
                        && m != ModuleManager.hudList && m != ModuleManager.iface) {
                    m.setEnabled(false);
                    any = true;
                }
            }
            if (any && !warned) {
                warned = true;
                mc.player.sendMessage(Text.literal(
                        "§7[Sunrop] §cСервер не в белом списке — модули выключены"), false);
                mc.player.sendMessage(Text.literal(
                        "§7[Sunrop] §7добавь адрес в §fconfig/sunrop-servers.txt"), false);
            }
            return;
        }
        warned = false;

        ModuleManager.tick();

        // автосохранение конфига раз в 30 секунд
        if (++autoSaveTick >= 600) {
            autoSaveTick = 0;
            ConfigFile.save();
        }
    }

    /** Свои бинды модулей — чтобы не плодить KeyBinding на каждый модуль. */
    private void handleModuleBinds(MinecraftClient mc) {
        if (mc.currentScreen != null) { down.clear(); return; }
        var win = mc.getWindow();

        for (Module m : ModuleManager.MODULES) {
            int k = m.key;
            if (k == GLFW.GLFW_KEY_UNKNOWN) continue;
            boolean pressed = InputUtil.isKeyPressed(win, k);
            if (pressed && down.add(k)) m.toggle();
            else if (!pressed) down.remove(k);
        }
    }

    /** Одиночка/LAN всегда; сервера — только из белого списка. */
    private boolean allowed(MinecraftClient mc) {
        if (mc.isInSingleplayer()) return true;
        ServerInfo info = mc.getCurrentServerEntry();
        if (info == null) return false;
        if (info.isLocal()) return true;
        ServerWhitelist.reloadIfStale();
        return ServerWhitelist.matches(info.address);
    }
}
