package ru.duo.aura.modules;

import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/** Быстро расходует пузырьки опыта. */
public class FasterXP extends Module {

    public final Setting.Num perTick = add(new Setting.Num("Throws per tick", 2, 1, 6, 1));
    public final Setting.Bool onlyHolding = add(new Setting.Bool("Only while holding use", true));

    public FasterXP() {
        super("FasterXP", "Быстрый розлив опыта", Category.CRYSTAL, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (!p.getMainHandStack().isOf(Items.EXPERIENCE_BOTTLE)) return;
        if (onlyHolding.value && !mc.options.useKey.isPressed()) return;

        for (int i = 0; i < perTick.asInt(); i++) {
            mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        }
        p.swingHand(Hand.MAIN_HAND);
    }
}
