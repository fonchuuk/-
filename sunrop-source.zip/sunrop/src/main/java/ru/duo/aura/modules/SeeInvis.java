package ru.duo.aura.modules;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

import java.util.HashMap;
import java.util.Map;

/**
 * Показывает невидимых.
 *
 * Невидимость — это просто синхронизированный флаг сущности: клиент ЗНАЕТ, что
 * игрок рядом и где он, ваниль просто решает его не рисовать. Поэтому самый
 * надёжный способ — снять этот флаг у себя на клиенте: модель рисуется обычным
 * способом, со скином, бронёй и ником. Дополнительно рисуем рамку (EspRenderer).
 */
public class SeeInvis extends Module {

    public final Setting.Bool reveal = add(new Setting.Bool("Reveal models", true));
    public final Setting.Bool boxes = add(new Setting.Bool("Boxes", true));
    public final Setting.Bool names = add(new Setting.Bool("Names", true));
    public final Setting.Bool mobs = add(new Setting.Bool("Mobs", true));
    public final Setting.Bool playersOpt = add(new Setting.Bool("Players", true));
    public final Setting.Num range = add(new Setting.Num("Range", 64, 8, 128, 1));
    public final Setting.Bool debug = add(new Setting.Bool("Debug chat", false));

    /** id сущности -> время последнего «он точно невидим» */
    private final Map<Integer, Long> marked = new HashMap<>();
    private int lastCount = -1;

    public SeeInvis() {
        super("SeeInvis", "Показывает невидимых существ", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;

        long now = System.currentTimeMillis();
        double rSq = range.value * range.value;
        int found = 0;

        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || !(e instanceof LivingEntity)) continue;
            if (!shows(e)) continue;
            if (e.getEntityPos().squaredDistanceTo(mc.player.getEntityPos()) > rSq) continue;

            if (e.isInvisible()) {
                marked.put(e.getId(), now);
                // снимаем флаг локально: ваниль начнёт рисовать модель
                if (reveal.value) e.setInvisible(false);
            }
            if (marked.containsKey(e.getId())) {
                found++;
                // держим раскрытым, пока метка свежая (10 сек)
                if (reveal.value && now - marked.get(e.getId()) < 10_000) e.setInvisible(false);
            }
        }

        // чистим протухшие метки
        marked.entrySet().removeIf(en -> now - en.getValue() > 10_000);

        if (debug.value && found != lastCount && mc.player != null) {
            lastCount = found;
            mc.player.sendMessage(Text.literal("§7[Sunrop] невидимых рядом: §f" + found), true);
        }
    }

    @Override
    public void onDisable() {
        marked.clear();
        lastCount = -1;
    }

    /** Эту сущность вообще обрабатываем? */
    public boolean shows(Entity e) {
        if (!(e instanceof LivingEntity)) return false;
        return e instanceof PlayerEntity ? playersOpt.value : mobs.value;
    }

    /** Эту сущность мы раскрыли — EspRenderer рисует ей рамку. */
    public boolean isRevealed(Entity e) {
        if (!isEnabled()) return false;
        return marked.containsKey(e.getId()) || e.isInvisible();
    }
}
