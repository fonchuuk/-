package ru.duo.aura.modules;

import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/** Броня и предмет в руке с прочностью над хотбаром. */
public class ArmorHud extends Module {

    public final Setting.Bool durability = add(new Setting.Bool("Durability", true));
    public final Setting.Bool mainHand = add(new Setting.Bool("Main hand", true));
    public final Setting.Num offsetY = add(new Setting.Num("Offset Y", 56, 20, 140, 1));

    public ArmorHud() {
        super("ArmorHud", "Показывает броню и прочность", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
    }
}
