package ru.duo.aura.modules;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CropBlock;
import net.minecraft.block.NetherWartBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.BlockBreaker;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.FarmModule;
import ru.duo.aura.core.Setting;

import java.util.List;

/** Собирает созревший урожай, сам подходит к грядкам и сажает заново. */
public class AutoFarm extends FarmModule {

    public final Setting.Bool replant = add(new Setting.Bool("Replant", true));
    public final Setting.Bool crops = add(new Setting.Bool("Crops", true));
    public final Setting.Bool netherWart = add(new Setting.Bool("Nether wart", true));
    public final Setting.Bool melons = add(new Setting.Bool("Melon/Pumpkin", true));
    public final Setting.Bool sugarCane = add(new Setting.Bool("Sugar cane", true));

    private int plantCooldown = 0;

    public AutoFarm() {
        super("AutoFarm", "Собирает урожай и сажает заново", Category.FARM, GLFW.GLFW_KEY_UNKNOWN);
        radius.value = 8;
        vertical.value = 3;
    }

    @Override
    protected boolean matches(BlockPos pos) {
        if (mc.world == null) return false;
        BlockState st = mc.world.getBlockState(pos);
        Block b = st.getBlock();

        if (crops.value && b instanceof CropBlock cb && cb.isMature(st)) return true;

        if (netherWart.value && b instanceof NetherWartBlock) {
            Integer age = st.getOrEmpty(Properties.AGE_3).orElse(null);
            if (age != null && age >= 3) return true;
        }

        if (melons.value && (b == Blocks.MELON || b == Blocks.PUMPKIN)) return true;

        if (sugarCane.value && b == Blocks.SUGAR_CANE) {
            return mc.world.getBlockState(pos.down()).isOf(Blocks.SUGAR_CANE);
        }
        return false;
    }

    @Override
    protected void idle() {
        if (!replant.value || mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (plantCooldown > 0) { plantCooldown--; return; }

        List<BlockPos> empty = BlockBreaker.find(mc, radius.asInt(), vertical.asInt(), pos -> {
            if (!mc.world.getBlockState(pos).isAir()) return false;
            BlockState below = mc.world.getBlockState(pos.down());
            return below.isOf(Blocks.FARMLAND) || below.isOf(Blocks.SOUL_SAND);
        }, 4.3);
        if (empty.isEmpty()) return;

        BlockPos pos = empty.get(0);
        boolean soulSand = mc.world.getBlockState(pos.down()).isOf(Blocks.SOUL_SAND);
        int slot = findSeedSlot(soulSand);
        if (slot == -1) return;

        int prev = mc.player.getInventory().getSelectedSlot();
        mc.player.getInventory().setSelectedSlot(slot);
        if (rotate.value) BlockBreaker.lookAtBlock(mc.player, pos.down());

        BlockHitResult hit = new BlockHitResult(
                Vec3d.ofCenter(pos.down(), 1.0), Direction.UP, pos.down(), false);
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
        mc.player.swingHand(Hand.MAIN_HAND);
        mc.player.getInventory().setSelectedSlot(prev);
        plantCooldown = 4;
    }

    private int findSeedSlot(boolean soulSand) {
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (soulSand) {
                if (s.isOf(Items.NETHER_WART)) return i;
            } else if (s.isOf(Items.WHEAT_SEEDS) || s.isOf(Items.CARROT)
                    || s.isOf(Items.POTATO) || s.isOf(Items.BEETROOT_SEEDS)) {
                return i;
            }
        }
        return -1;
    }
}
