package ru.duo.aura.modules;

import net.minecraft.block.BlockState;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/** Сам ставит в руку лучший инструмент под блок, по которому бьёшь. */
public class AutoTool extends Module {

    public final Setting.Bool onlyWhenMining = add(new Setting.Bool("Only while mining", true));
    public final Setting.Bool saveTools = add(new Setting.Bool("Save low durability", true));
    public final Setting.Num minDurability = add(new Setting.Num("Min durability", 5, 1, 50, 1));

    public AutoTool() {
        super("AutoTool", "Сам выбирает нужный инструмент", Category.OPTIMIZER, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.crosshairTarget == null) return;
        if (mc.crosshairTarget.getType() != HitResult.Type.BLOCK) return;
        if (onlyWhenMining.value && !mc.options.attackKey.isPressed()) return;

        BlockHitResult hit = (BlockHitResult) mc.crosshairTarget;
        BlockState state = mc.world.getBlockState(hit.getBlockPos());
        if (state.isAir()) return;

        int best = -1;
        float bestSpeed = 1.0f;
        for (int i = 0; i < 9; i++) {
            var stack = mc.player.getInventory().getStack(i);
            if (stack.isEmpty()) continue;
            if (saveTools.value && stack.isDamageable()
                    && stack.getMaxDamage() - stack.getDamage() <= minDurability.asInt()) continue;
            float sp = stack.getMiningSpeedMultiplier(state);
            if (sp > bestSpeed) { bestSpeed = sp; best = i; }
        }
        if (best >= 0 && mc.player.getInventory().getSelectedSlot() != best) {
            mc.player.getInventory().setSelectedSlot(best);
        }
    }
}
