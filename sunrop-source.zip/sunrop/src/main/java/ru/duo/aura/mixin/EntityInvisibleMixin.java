package ru.duo.aura.mixin;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.duo.aura.core.ModuleManager;
import ru.duo.aura.modules.SeeInvis;

/**
 * То же, что делают Tweakeroo («Render Invisible Entities») и профильные моды:
 * невидимость — это просто проверка Entity#isInvisibleTo, и в режиме наблюдателя
 * она всегда false. Мы возвращаем false сами, когда включён SeeInvis, —
 * и игра рисует существо обычным способом, ничего не ломая в его состоянии.
 */
@Mixin(Entity.class)
public abstract class EntityInvisibleMixin {

    @Inject(method = "isInvisibleTo", at = @At("HEAD"), cancellable = true)
    private void sunrop$reveal(PlayerEntity player, CallbackInfoReturnable<Boolean> cir) {
        SeeInvis m = ModuleManager.seeInvis;
        if (m == null || !m.isEnabled() || !m.reveal.value) return;
        Entity self = (Entity) (Object) this;
        if (!m.shows(self)) return;
        cir.setReturnValue(false);
    }
}
