package ru.duo.aura.core;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {

    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    public final String name;
    public final String description;
    public final Category category;
    public int key;
    private boolean enabled;

    public final List<Setting> settings = new ArrayList<>();
    /** раскрыт ли список настроек в ClickGUI */
    public boolean expanded = false;

    protected Module(String name, String description, Category category, int key) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.key = key;
    }

    protected <T extends Setting> T add(T s) {
        settings.add(s);
        return s;
    }

    public boolean isEnabled() { return enabled; }

    public void setEnabled(boolean v) {
        if (enabled == v) return;
        enabled = v;
        if (v) onEnable(); else onDisable();
    }

    public void toggle() {
        setEnabled(!enabled);
        if (mc.player != null && ModuleManager.chatFeedback) {
            mc.player.sendMessage(Text.literal(
                    (enabled ? "§a+ §f" : "§c- §7") + name), true);
        }
    }

    /** Текст справа от имени в HUD-списке, например "[JUMP]". */
    public String hudSuffix() { return ""; }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
}
