package ru.duo.aura.gui;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.ConfigFile;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Friends;
import ru.duo.aura.core.Lang;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.ModuleManager;
import ru.duo.aura.core.Setting;
import ru.duo.aura.core.Theme;
import ru.duo.aura.modules.Waypoints;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Компактное окно по центру экрана: слева сайдбар (категории + разделы),
 * по центру карточки модулей, справа настройки выбранного.
 * Разделы «Конфигурации», «Друзья», «Путевые точки» — рабочие страницы.
 */
public class ClickGui extends Screen {

    private enum Page { MODULES, BINDS, CONFIGS, FRIENDS, WAYPOINTS }

    private static final int SIDE_W = 126;
    private static final int LIST_W = 176;

    private static Category selectedCat = null;   // null = «Все»
    private static Module selected = null;
    private static Page page = Page.MODULES;
    private static String search = "";

    private int listTarget = 0, setTarget = 0;
    private int listScroll = 0, setScroll = 0;
    private Setting.Num sliding;
    private int slideX, slideW;
    private Module binding;
    private boolean searchFocus = false;
    private String toast = null;
    private long toastAt = 0;

    // геометрия окна
    private int wx, wy, ww, wh, listX, setX, setW, topY, botY;

    /** Свой шрифт интерфейса — assets/sunrop/font/gui.json (Inter). */
    private static final Identifier FONT = Identifier.of("sunrop", "gui");
    /** Логотип клиента — assets/sunrop/textures/logo.png */
    private static final Identifier LOGO = Identifier.of("sunrop", "textures/logo.png");

    private static Text f(String s) {
        var iface = ModuleManager.iface;
        if (iface != null && iface.font.is("VANILLA")) return Text.literal(s);
        return Text.literal(s).setStyle(Style.EMPTY.withFont(new net.minecraft.text.StyleSpriteSource.Font(FONT)));
    }

    private int fw(String s) {
        return this.textRenderer.getWidth(f(s));
    }

    private String ftrim(String s, int max) {
        if (fw(s) <= max) return s;
        String out = s;
        while (out.length() > 1 && fw(out + "...") > max) out = out.substring(0, out.length() - 1);
        return out + "...";
    }

    public ClickGui() {
        super(Text.literal("Sunrop"));
    }

    @Override
    public boolean shouldPause() { return false; }

    private void layout() {
        ww = Math.min(this.width - 30, 640);
        wh = Math.min(this.height - 30, 340);
        wx = (this.width - ww) / 2;
        wy = (this.height - wh) / 2;
        listX = wx + SIDE_W;
        setX = listX + LIST_W;
        setW = wx + ww - setX - 8;
        topY = wy + 40;
        botY = wy + wh - 8;
        if (selected == null && !ModuleManager.MODULES.isEmpty()) selected = ModuleManager.MODULES.get(0);
    }

    // ------------------------------------------------------------- данные

    private List<Module> listedCache;
    private String listedKey = null;

    private List<Module> listed() {
        String key = (selectedCat == null ? "*" : selectedCat.name()) + "|" + search;
        if (listedCache != null && key.equals(listedKey)) return listedCache;
        List<Module> out = new ArrayList<>();
        String q = search.toLowerCase(Locale.ROOT);
        for (Module m : ModuleManager.MODULES) {
            if (selectedCat != null && m.category != selectedCat) continue;
            if (!q.isEmpty()
                    && !m.name.toLowerCase(Locale.ROOT).contains(q)
                    && !Lang.t(m.name).toLowerCase(Locale.ROOT).contains(q)) continue;
            out.add(m);
        }
        listedKey = key;
        listedCache = out;
        return out;
    }

    private int enabledIn(Category c) {
        int n = 0;
        for (Module m : ModuleManager.MODULES) if (m.category == c && m.isEnabled()) n++;
        return n;
    }

    private int cardH(Setting st) { return st instanceof Setting.Bool ? 26 : 36; }

    private void say(String s) { toast = s; toastAt = System.currentTimeMillis(); }

    // ---------------------------------------------------------- отрисовка

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        layout();
        Anim.frame();
        int accent = Theme.accent();

        // плавное появление окна: затемнение + лёгкий подъём снизу
        float open = Anim.ease(Anim.to("open", 1f, 11f));
        int dim = (int) (0x99 * open) << 24;
        ctx.fill(0, 0, this.width, this.height, dim);
        int rise = Math.round((1f - open) * 14f);
        wy += rise;
        topY += rise;
        botY += rise;
        Draw.shadow(ctx, wx, wy, wx + ww, wy + wh, 6);
        Draw.round(ctx, wx, wy, wx + ww, wy + wh, 8, 0xFF0C0C10);
        Draw.round(ctx, wx, wy, wx + SIDE_W, wy + wh, 8, 0xFF101015);
        ctx.fill(listX - 1, wy + 8, listX, wy + wh - 8, 0xFF1B1B22);
        ctx.fill(setX - 5, wy + 8, setX - 4, wy + wh - 8, 0xFF1B1B22);

        sidebar(ctx, mouseX, mouseY, accent);
        header(ctx, accent);

        ctx.enableScissor(listX, topY - 2, wx + ww, botY);
        switch (page) {
            case MODULES -> { moduleList(ctx, mouseX, mouseY, accent); settings(ctx, mouseX, mouseY, accent); }
            case BINDS -> bindsPage(ctx, mouseX, mouseY, accent);
            case CONFIGS -> configsPage(ctx, mouseX, mouseY, accent);
            case FRIENDS -> friendsPage(ctx, mouseX, mouseY, accent);
            case WAYPOINTS -> waypointsPage(ctx, mouseX, mouseY, accent);
        }
        ctx.disableScissor();

        if (binding != null) {
            String t = Lang.t("Нажми клавишу для") + " " + Lang.t(binding.name);
            center(ctx, t, accent);
        } else if (toast != null && System.currentTimeMillis() - toastAt < 2500) {
            center(ctx, toast, accent);
        }
    }

    private void center(DrawContext ctx, String t, int accent) {
        int w = fw(t) + 16;
        int bx = wx + ww / 2 - w / 2, by = wy + wh + 6;
        Draw.round(ctx, bx, by, bx + w, by + 18, 5, 0xE617171D);
        ctx.drawText(this.textRenderer, f(t), bx + 8, by + 5, accent, false);
    }

    private void sidebar(DrawContext ctx, int mx, int my, int accent) {
        ctx.drawTexture(net.minecraft.client.gl.RenderPipelines.GUI_TEXTURED, LOGO,
                wx + 9, wy + 9, 0.0f, 0.0f, 15, 15, 64, 64, 64, 64);
        ctx.drawText(this.textRenderer, f("Sunrop"), wx + 28, wy + 13, 0xFFFFFFFF, false);

        ctx.drawText(this.textRenderer, f(Lang.t("Категории")), wx + 11, wy + 34, 0xFF555963, false);
        int y = wy + 45;
        y = sideRow(ctx, y, Lang.t("Все"), -1, page == Page.MODULES && selectedCat == null, mx, my, accent);
        for (Category c : Category.values()) {
            y = sideRow(ctx, y, Lang.t(c.title), enabledIn(c),
                    page == Page.MODULES && selectedCat == c, mx, my, accent);
        }

        ctx.drawText(this.textRenderer, f(Lang.t("Настройки")), wx + 11, y + 5, 0xFF555963, false);
        y += 16;
        y = sideRow(ctx, y, Lang.t("Клавиши"), -1, page == Page.BINDS, mx, my, accent);
        y = sideRow(ctx, y, Lang.t("Конфигурации"), -1, page == Page.CONFIGS, mx, my, accent);
        y = sideRow(ctx, y, Lang.t("Друзья"), Friends.count(), page == Page.FRIENDS, mx, my, accent);
        sideRow(ctx, y, Lang.t("Путевые точки"),
                ModuleManager.waypoints != null ? ModuleManager.waypoints.points.size() : -1,
                page == Page.WAYPOINTS, mx, my, accent);

        String nick = this.client != null && this.client.getSession() != null
                ? this.client.getSession().getUsername() : "Player";
        ctx.drawText(this.textRenderer, f(nick), wx + 11, wy + wh - 24, 0xFFBFC2CF, false);
        ctx.drawText(this.textRenderer, f("Sunrop 3.10"), wx + 11, wy + wh - 14, 0xFF555963, false);
    }

    private int sideRow(DrawContext ctx, int y, String label, int badge,
                        boolean active, int mx, int my, int accent) {
        boolean hot = mx > wx + 6 && mx < wx + SIDE_W - 6 && my >= y && my < y + 16;
        float ha = Anim.to("sh" + label, hot ? 1f : 0f, 14f);
        float aa = Anim.ease(Anim.to("sa" + label, active ? 1f : 0f, 13f));
        int bg = Theme.mix(0xFF101015, 0xFF15161B, ha);
        bg = Theme.mix(bg, 0xFF1C1D26, aa);
        Draw.round(ctx, wx + 6, y, wx + SIDE_W - 6, y + 16, 4, bg);
        if (aa > 0.01f) {
            int bar = Math.round(8 * aa);
            ctx.fill(wx + 6, y + 8 - bar / 2, wx + 8, y + 8 + bar / 2, Theme.alpha(accent, (int) (255 * aa)));
        }
        ctx.drawText(this.textRenderer, f(label), wx + 14 + Math.round(2 * aa), y + 4,
                Theme.mix(0xFF9499A5, 0xFFFFFFFF, aa), false);
        if (badge > 0) {
            String b = String.valueOf(badge);
            int bw = fw(b);
            ctx.drawText(this.textRenderer, f(b), wx + SIDE_W - 12 - bw, y + 4, accent, false);
        }
        return y + 18;
    }

    private void header(DrawContext ctx, int accent) {
        String title = switch (page) {
            case MODULES -> selectedCat == null ? Lang.t("Все") : Lang.t(selectedCat.title);
            case BINDS -> Lang.t("Клавиши");
            case CONFIGS -> Lang.t("Конфигурации");
            case FRIENDS -> Lang.t("Друзья");
            case WAYPOINTS -> Lang.t("Путевые точки");
        };
        ctx.drawTexture(net.minecraft.client.gl.RenderPipelines.GUI_TEXTURED, LOGO,
                listX + 8, wy + 8, 0.0f, 0.0f, 16, 16, 64, 64, 64, 64);
        ctx.drawText(this.textRenderer, f(title), listX + 28, wy + 13, 0xFFFFFFFF, false);

        if (page != Page.MODULES) return;
        int sx = setX, sw = setW;
        Draw.round(ctx, sx, wy + 10, sx + sw, wy + 26, 4, searchFocus ? 0xFF1E1F28 : 0xFF15161B);
        if (searchFocus) ctx.fill(sx, wy + 10, sx + 2, wy + 26, accent);
        String shown = search.isEmpty() && !searchFocus ? Lang.t("Поиск") : search + (searchFocus ? "_" : "");
        ctx.drawText(this.textRenderer, f(shown), sx + 7, wy + 14,
                search.isEmpty() && !searchFocus ? 0xFF555963 : 0xFFE8E8EF, false);
    }

    private void moduleList(DrawContext ctx, int mx, int my, int accent) {
        List<Module> mods = listed();
        int rowH = 28;
        listTarget = Math.max(0, Math.min(listTarget, Math.max(0, mods.size() * rowH - (botY - topY))));
        listScroll = Math.round(Anim.to("scrollL", listTarget, 16f));
        int y = topY - listScroll;
        for (Module m : mods) {
            if (y + rowH > topY - rowH && y < botY) {
                boolean hot = mx > listX + 6 && mx < setX - 8 && my >= y && my < y + rowH - 4;
                boolean sel = m == selected;
                float ha = Anim.to("h" + m.name, hot ? 1f : 0f, 14f);
                float sa = Anim.ease(Anim.to("s" + m.name, sel ? 1f : 0f, 12f));
                int bg = Theme.mix(0xFF121318, 0xFF16171D, ha);
                bg = Theme.mix(bg, 0xFF1C1D26, sa);
                Draw.round(ctx, listX + 6, y, setX - 8, y + rowH - 4, 5, bg);
                if (sa > 0.01f) {
                    int bar = Math.round((rowH - 14) * sa);
                    int by0 = y + (rowH - 4) / 2 - bar / 2;
                    ctx.fill(listX + 6, by0, listX + 8, by0 + bar, Theme.alpha(accent, (int) (255 * sa)));
                }
                String n = ftrim(Lang.t(m.name), LIST_W - 52);
                ctx.drawText(this.textRenderer, f(n), listX + 13, y + 4,
                        m.isEnabled() ? accent : 0xFFD8DAE2, false);
                String d = ftrim(Lang.t(m.description), LIST_W - 52);
                ctx.drawText(this.textRenderer, f(d), listX + 13, y + 14, 0xFF5B5F6B, false);
                Draw.toggle(ctx, setX - 32, y + 6, Anim.to("t" + m.name, m.isEnabled() ? 1f : 0f, 16f), accent);
            }
            y += rowH;
        }
    }

    private void settings(DrawContext ctx, int mx, int my, int accent) {
        Module m = selected;
        if (m == null) return;
        int x1 = setX, x2 = setX + setW;
        setScroll = Math.round(Anim.to("scrollR", setTarget, 16f));
        int y = topY - setScroll;

        Draw.round(ctx, x1, y, x2, y + 36, 6, 0xFF14151A);
        ctx.drawText(this.textRenderer, f(Lang.t(m.name)), x1 + 9, y + 7, 0xFFFFFFFF, false);
        ctx.drawText(this.textRenderer,
                f(ftrim(Lang.t(m.description), setW - 50)), x1 + 9, y + 20, 0xFF6A6E79, false);
        Draw.toggle(ctx, x2 - 28, y + 12, Anim.to("T" + m.name, m.isEnabled() ? 1f : 0f, 16f), accent);
        y += 40;

        Draw.round(ctx, x1, y, x2, y + 22, 6, 0xFF14151A);
        ctx.drawText(this.textRenderer, f(Lang.t("Клавиша")), x1 + 9, y + 7, 0xFFD8DAE2, false);
        String kn = keyName(m.key);
        int kw = fw(kn) + 12;
        Draw.round(ctx, x2 - 8 - kw, y + 4, x2 - 8, y + 18, 4,
                binding == m ? Theme.alpha(accent, 90) : 0xFF1E1F27);
        ctx.drawText(this.textRenderer, f(kn), x2 - 8 - kw + 6, y + 7, binding == m ? accent : 0xFFBFC2CF, false);
        y += 26;

        for (Setting st : m.settings) {
            int h = cardH(st);
            Draw.round(ctx, x1, y, x2, y + h - 4, 6, 0xFF14151A);
            ctx.drawText(this.textRenderer,
                    f(ftrim(Lang.t(st.name), setW - 70)), x1 + 9, y + 7, 0xFFD8DAE2, false);

            if (st instanceof Setting.Bool b) {
                Draw.toggle(ctx, x2 - 28, y + 5, Anim.to("b" + m.name + st.name, b.value ? 1f : 0f, 16f), accent);
            } else if (st instanceof Setting.Mode mo) {
                int bw = Math.min(120, setW - 20);
                Draw.round(ctx, x2 - 8 - bw, y + 17, x2 - 8, y + 31, 4, 0xFF1C1D25);
                ctx.drawText(this.textRenderer,
                        f(ftrim(Lang.t(mo.get()), bw - 16)), x2 - 8 - bw + 6, y + 20,
                        0xFFE8E8EF, false);
            } else if (st instanceof Setting.Num n) {
                String v = n.display();
                ctx.drawText(this.textRenderer, f(v), x2 - 8 - fw(v), y + 7, accent, false);
                Draw.slider(ctx, x1 + 9, y + 23, setW - 18,
                        Anim.to("n" + m.name + st.name, (float) n.percent(), 18f), accent, sliding == n);
            }
            y += h;
        }

        Draw.round(ctx, x1, y, x2, y + 38, 6, 0xFF14151A);
        ctx.drawText(this.textRenderer, f(Lang.t("Акцентный цвет")), x1 + 9, y + 6, 0xFFD8DAE2, false);
        for (int i = 0; i < Theme.ACCENT_NAMES.length; i++) {
            int cx = x1 + 9 + i * 18;
            int old = Theme.accentIndex;
            Theme.accentIndex = i;
            int col = Theme.accent();
            Theme.accentIndex = old;
            if (old == i) Draw.round(ctx, cx - 2, y + 18, cx + 14, y + 34, 5, Theme.alpha(col, 110));
            Draw.round(ctx, cx, y + 20, cx + 12, y + 32, 4, col);
        }
        y += 44;
        setTarget = Math.max(0, Math.min(setTarget, Math.max(0, (y + setScroll) - botY + 6)));
    }

    // ------------------------------------------------------------ страницы

    private int pageCard(DrawContext ctx, int y, String title, String sub, String action, int accent, int mx, int my) {
        int x1 = listX + 8, x2 = wx + ww - 8;
        boolean hot = mx > x1 && mx < x2 && my >= y && my < y + 30;
        Draw.round(ctx, x1, y, x2, y + 30, 6, hot ? 0xFF1A1B22 : 0xFF14151A);
        ctx.drawText(this.textRenderer, f(title), x1 + 10, y + 6, 0xFFE8E8EF, false);
        ctx.drawText(this.textRenderer, f(sub), x1 + 10, y + 17, 0xFF5B5F6B, false);
        if (action != null) {
            int bw = fw(action) + 14;
            Draw.round(ctx, x2 - 10 - bw, y + 8, x2 - 10, y + 23, 4, Theme.alpha(accent, 70));
            ctx.drawText(this.textRenderer, f(action), x2 - 10 - bw + 7, y + 11, accent, false);
        }
        return y + 34;
    }

    /** Все бинды в одном месте: клик по строке — назначить клавишу. */
    private List<Module> bindList() {
        List<Module> out = new ArrayList<>();
        if (ModuleManager.guiBind != null) out.add(ModuleManager.guiBind);
        for (Module m : ModuleManager.MODULES) {
            if (m == ModuleManager.guiBind) continue;
            out.add(m);
        }
        return out;
    }

    private void bindsPage(DrawContext ctx, int mx, int my, int accent) {
        int y = topY - listScroll;
        for (Module m : bindList()) {
            if (y > botY) break;
            if (y >= topY - 34) {
                String act = binding == m ? Lang.t("Нажми клавишу") : keyName(m.key);
                String sub = m == ModuleManager.guiBind
                        ? Lang.t("Открывает меню клиента")
                        : Lang.t(m.category.title) + " · " + Lang.t(m.description);
                y = pageCard(ctx, y, Lang.t(m.name), ftrim(sub, setW + LIST_W - 120), act, accent, mx, my);
            } else {
                y += 34;
            }
        }
    }

    private boolean clickBinds(double my) {
        int y = topY - listScroll;
        for (Module m : bindList()) {
            if (my >= y && my < y + 30) {
                binding = (binding == m) ? null : m;
                return true;
            }
            y += 34;
        }
        return true;
    }

    private void configsPage(DrawContext ctx, int mx, int my, int accent) {
        int y = topY;
        y = pageCard(ctx, y, Lang.t("Сохранить конфиг"), "config/sunrop.txt", Lang.t("Сохранить"), accent, mx, my);
        y = pageCard(ctx, y, Lang.t("Загрузить конфиг"), Lang.t("Перечитать файл с диска"), Lang.t("Загрузить"), accent, mx, my);
        y = pageCard(ctx, y, Lang.t("Сбросить настройки"), Lang.t("Выключить все модули"), Lang.t("Сброс"), accent, mx, my);
        int on = 0;
        for (Module m : ModuleManager.MODULES) if (m.isEnabled()) on++;
        pageCard(ctx, y, Lang.t("Состояние"),
                ModuleManager.MODULES.size() + " " + Lang.t("модулей") + ", " + Lang.t("включено") + ": " + on,
                null, accent, mx, my);
    }

    private void friendsPage(DrawContext ctx, int mx, int my, int accent) {
        int y = topY;
        y = pageCard(ctx, y, Lang.t("Добавить по прицелу"),
                Lang.t("Наведись на игрока и нажми клавишу модуля Friends"), null, accent, mx, my);
        List<String> all = Friends.all();
        if (all.isEmpty()) {
            pageCard(ctx, y, Lang.t("Список пуст"), "config/sunrop-friends.txt", null, accent, mx, my);
            return;
        }
        y -= listScroll;
        for (String n : all) {
            if (y > botY) break;
            if (y >= topY - 30) y = pageCard(ctx, y, n, Lang.t("Не трогает аура"), Lang.t("Удалить"), accent, mx, my);
            else y += 34;
        }
    }

    private void waypointsPage(DrawContext ctx, int mx, int my, int accent) {
        Waypoints wp = ModuleManager.waypoints;
        int y = topY;
        if (wp == null) return;
        y = pageCard(ctx, y, Lang.t("Поставить здесь"), Lang.t("Метка в текущей точке"), Lang.t("Добавить"), accent, mx, my);
        y = pageCard(ctx, y, Lang.t("Очистить все"), wp.points.size() + " " + Lang.t("меток"), Lang.t("Очистить"), accent, mx, my);
        y -= listScroll;
        for (Waypoints.Point p : new ArrayList<>(wp.points)) {
            if (y > botY) break;
            if (y >= topY - 30) {
                String pos = (int) p.pos().x + ", " + (int) p.pos().y + ", " + (int) p.pos().z;
                y = pageCard(ctx, y, p.name(), pos, Lang.t("Удалить"), accent, mx, my);
            } else y += 34;
        }
    }

    // --------------------------------------------------------------- ввод

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        layout();
        double mx = click.x(), my = click.y();
        int btn = click.button();
        if (mx < wx || mx > wx + ww || my < wy || my > wy + wh) return true;

        // сайдбар
        if (mx < listX) {
            searchFocus = false;
            int y = wy + 45;
            if (my >= y && my < y + 16) { page = Page.MODULES; selectedCat = null; listScroll = 0; listTarget = 0; listedCache = null; return true; }
            y += 18;
            for (Category c : Category.values()) {
                if (my >= y && my < y + 16) { page = Page.MODULES; selectedCat = c; listScroll = 0; listTarget = 0; listedCache = null; return true; }
                y += 18;
            }
            y += 16;
            if (my >= y && my < y + 16) { page = Page.BINDS; listScroll = 0; listTarget = 0; return true; }
            if (my >= y + 18 && my < y + 34) { page = Page.CONFIGS; listScroll = 0; listTarget = 0; return true; }
            if (my >= y + 36 && my < y + 52) { page = Page.FRIENDS; listScroll = 0; listTarget = 0; return true; }
            if (my >= y + 54 && my < y + 70) { page = Page.WAYPOINTS; listScroll = 0; listTarget = 0; return true; }
            return true;
        }

        if (page == Page.BINDS) return clickBinds(my);
        if (page == Page.CONFIGS) return clickConfigs(my);
        if (page == Page.FRIENDS) return clickFriends(my);
        if (page == Page.WAYPOINTS) return clickWaypoints(my);

        // поиск
        if (my >= wy + 10 && my <= wy + 26 && mx >= setX) {
            searchFocus = true;
            if (btn == 1) { search = ""; listedCache = null; }
            return true;
        }
        searchFocus = false;

        // список модулей
        if (mx < setX - 6 && my >= topY) {
            int rowH = 28, y = topY - listScroll;
            for (Module m : listed()) {
                if (my >= y && my < y + rowH - 4) {
                    if (mx >= setX - 34 || btn == 1) m.toggle();
                    else { selected = m; setTarget = 0; }
                    return true;
                }
                y += rowH;
            }
            return true;
        }

        // настройки
        Module m = selected;
        if (m != null && mx >= setX && my >= topY) {
            int x1 = setX;
            int y = topY - setScroll;
            if (my >= y && my < y + 36) { m.toggle(); return true; }
            y += 40;
            if (my >= y && my < y + 22) { binding = (binding == m) ? null : m; return true; }
            y += 26;
            for (Setting st : m.settings) {
                int h = cardH(st);
                if (my >= y && my < y + h - 4) {
                    if (st instanceof Setting.Bool b) { b.toggle(); applyLive(); }
                    else if (st instanceof Setting.Mode mo) {
                        if (btn == 1) mo.index = (mo.index - 1 + mo.modes.length) % mo.modes.length;
                        else mo.next();
                        applyLive();
                    } else if (st instanceof Setting.Num n) {
                        sliding = n; slideX = x1 + 9; slideW = setW - 18;
                        n.setFromPercent((mx - slideX) / (double) slideW);
                    }
                    return true;
                }
                y += h;
            }
            if (my >= y + 18 && my < y + 34) {
                for (int i = 0; i < Theme.ACCENT_NAMES.length; i++) {
                    int cx = x1 + 9 + i * 18;
                    if (mx >= cx - 2 && mx <= cx + 14) { Theme.accentIndex = i; applyLive(); return true; }
                }
            }
        }
        return true;
    }

    private boolean clickConfigs(double my) {
        int y = topY;
        if (my >= y && my < y + 30) { applyLive(); ConfigFile.save(); say(Lang.t("Конфиг сохранён")); return true; }
        if (my >= y + 34 && my < y + 64) { ConfigFile.load(); Friends.load(); applyLive(); say(Lang.t("Конфиг загружен")); return true; }
        if (my >= y + 68 && my < y + 98) {
            for (Module m : ModuleManager.MODULES) {
                if (m != ModuleManager.iface && m != ModuleManager.friendManager) m.setEnabled(false);
            }
            say(Lang.t("Все модули выключены"));
            return true;
        }
        return true;
    }

    private boolean clickFriends(double my) {
        int y = topY + 34 - listScroll;
        for (String n : Friends.all()) {
            if (my >= y && my < y + 30) { Friends.toggle(n); say(n + " — " + Lang.t("удалён")); return true; }
            y += 34;
        }
        return true;
    }

    private boolean clickWaypoints(double my) {
        Waypoints wp = ModuleManager.waypoints;
        if (wp == null) return true;
        int y = topY;
        if (my >= y && my < y + 30) {
            if (this.client != null && this.client.player != null) {
                wp.points.add(new Waypoints.Point("Метка " + (wp.points.size() + 1),
                        this.client.player.getEntityPos()));
                say(Lang.t("Метка поставлена"));
            }
            return true;
        }
        if (my >= y + 34 && my < y + 64) { wp.points.clear(); say(Lang.t("Метки стёрты")); return true; }
        y = topY + 68 - listScroll;
        for (int i = 0; i < wp.points.size(); i++) {
            if (my >= y && my < y + 30) { wp.points.remove(i); return true; }
            y += 34;
        }
        return true;
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (sliding != null) { sliding.setFromPercent((click.x() - slideX) / (double) slideW); return true; }
        return super.mouseDragged(click, dx, dy);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (sliding != null) { sliding = null; applyLive(); }
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double amount) {
        layout();
        if (page == Page.MODULES && mx >= setX) setTarget = Math.max(0, setTarget - (int) Math.signum(amount) * 22);
        else listTarget = Math.max(0, listTarget - (int) Math.signum(amount) * 28);
        return true;
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (searchFocus && input.isValidChar()) {
            search += input.asString();
            listedCache = null;
            listScroll = 0; listTarget = 0; listedCache = null;
            return true;
        }
        return super.charTyped(input);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (binding != null) {
            binding.key = (key == GLFW.GLFW_KEY_ESCAPE) ? GLFW.GLFW_KEY_UNKNOWN : key;
            binding = null;
            return true;
        }
        if (searchFocus) {
            if (key == GLFW.GLFW_KEY_BACKSPACE) {
                if (!search.isEmpty()) search = search.substring(0, search.length() - 1);
                listedCache = null;
                return true;
            }
            if (key == GLFW.GLFW_KEY_ESCAPE) { searchFocus = false; search = ""; listedCache = null; return true; }
            if (key == GLFW.GLFW_KEY_ENTER) { searchFocus = false; return true; }
        }
        if (key == GLFW.GLFW_KEY_RIGHT_CONTROL) {
            this.client.setScreen(new HudEditor());
            return true;
        }
        return super.keyPressed(input);
    }

    private void applyLive() {
        if (ModuleManager.iface != null) ModuleManager.iface.apply();
    }

    @Override
    public void close() {
        applyLive();
        ConfigFile.save();
        super.close();
    }

    public static String keyName(int key) {
        if (key == GLFW.GLFW_KEY_UNKNOWN) return Lang.t("NONE");
        String n = GLFW.glfwGetKeyName(key, 0);
        if (n != null) return n.toUpperCase(Locale.ROOT);
        return switch (key) {
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "Right Shift";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "Left Shift";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "Left Ctrl";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "Right Ctrl";
            case GLFW.GLFW_KEY_TAB -> "Tab";
            case GLFW.GLFW_KEY_SPACE -> "Space";
            default -> "Key" + key;
        };
    }
}
