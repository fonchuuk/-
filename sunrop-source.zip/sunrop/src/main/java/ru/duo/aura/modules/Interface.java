package ru.duo.aura.modules;

import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Lang;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.ModuleManager;
import ru.duo.aura.core.Setting;
import ru.duo.aura.core.Theme;

/** Настройки самого клиента: язык интерфейса, сообщения в чат. */
public class Interface extends Module {

    public final Setting.Mode language = add(new Setting.Mode("Language", 0, "EN", "RU"));
    public final Setting.Mode accent = add(new Setting.Mode("Accent", 0, Theme.ACCENT_NAMES));
    public final Setting.Mode theme = add(new Setting.Mode("Theme", 0, "DARK", "LIGHT"));
    public final Setting.Mode font = add(new Setting.Mode("GUI font", 1, "VANILLA", "CUSTOM"));
    public final Setting.Bool chat = add(new Setting.Bool("Chat feedback", true));

    public Interface() {
        super("Interface", "Язык и поведение клиента", Category.CLIENT, GLFW.GLFW_KEY_UNKNOWN);
        setEnabled(true);
    }

    @Override
    public void onTick() {
        apply();
    }

    public void apply() {
        Lang.russian = language.is("RU");
        Theme.accentIndex = accent.index;
        Theme.light = theme.is("LIGHT");
        ModuleManager.chatFeedback = chat.value;
    }
}
