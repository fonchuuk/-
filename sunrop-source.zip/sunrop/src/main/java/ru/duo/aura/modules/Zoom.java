package ru.duo.aura.modules;

import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/** Оптический зум: уменьшает FOV, пока модуль включён. */
public class Zoom extends Module {

    public final Setting.Num factor = add(new Setting.Num("Factor", 4, 1.5, 10, 0.5));
    public final Setting.Bool smoothCam = add(new Setting.Bool("Smooth camera", true));

    private int savedFov = -1;
    private boolean savedSmooth;

    public Zoom() {
        super("Zoom", "Приближение по клавише", Category.RENDER, GLFW.GLFW_KEY_C);
    }

    @Override
    public void onEnable() {
        if (mc.options == null) return;
        savedFov = mc.options.getFov().getValue();
        savedSmooth = mc.options.smoothCameraEnabled;
        mc.options.getFov().setValue(Math.max(1, (int) (savedFov / factor.value)));
        if (smoothCam.value) mc.options.smoothCameraEnabled = true;
    }

    @Override
    public void onDisable() {
        if (mc.options == null || savedFov < 0) return;
        mc.options.getFov().setValue(savedFov);
        mc.options.smoothCameraEnabled = savedSmooth;
        savedFov = -1;
    }

    @Override
    public String hudSuffix() { return " §7[" + (int) factor.value + "x]"; }
}
