package ru.duo.aura.gui;

import net.minecraft.client.gui.DrawContext;
import ru.duo.aura.core.Theme;

/** Мелкие помощники отрисовки: скруглённые прямоугольники, тени, градиенты. */
public class Draw {

    /** Прямоугольник со срезанными углами — визуально читается как скруглённый. */
    public static void round(DrawContext ctx, int x1, int y1, int x2, int y2, int r, int color) {
        if (x2 - x1 <= 0 || y2 - y1 <= 0) return;
        r = Math.max(0, Math.min(r, Math.min(x2 - x1, y2 - y1) / 2));
        ctx.fill(x1 + r, y1, x2 - r, y2, color);
        ctx.fill(x1, y1 + r, x1 + r, y2 - r, color);
        ctx.fill(x2 - r, y1 + r, x2, y2 - r, color);
        for (int i = 0; i < r; i++) {
            int inset = r - (int) Math.round(Math.sqrt(r * r - (r - i - 1) * (r - i - 1)));
            ctx.fill(x1 + inset, y1 + i, x2 - inset, y1 + i + 1, color);
            ctx.fill(x1 + inset, y2 - i - 1, x2 - inset, y2 - i, color);
        }
    }

    public static void roundBorder(DrawContext ctx, int x1, int y1, int x2, int y2, int r, int color) {
        round(ctx, x1, y1, x2, y2, r, color);
    }

    /** Мягкая тень под окном: несколько прямых полос вместо скруглений. */
    public static void shadow(DrawContext ctx, int x1, int y1, int x2, int y2, int spread) {
        for (int i = spread; i > 0; i--) {
            int a = (int) (22.0 * (1.0 - (double) i / spread));
            if (a <= 0) continue;
            int c = a << 24;
            ctx.fill(x1 - i, y1 - i + 2, x2 + i, y1 - i + 3, c);
            ctx.fill(x1 - i, y2 + i + 1, x2 + i, y2 + i + 2, c);
            ctx.fill(x1 - i, y1 - i + 2, x1 - i + 1, y2 + i + 2, c);
            ctx.fill(x2 + i - 1, y1 - i + 2, x2 + i, y2 + i + 2, c);
        }
    }

    /** Вертикальный градиент. */
    public static void vGradient(DrawContext ctx, int x1, int y1, int x2, int y2, int top, int bottom) {
        int h = y2 - y1;
        if (h <= 0) return;
        for (int i = 0; i < h; i++) {
            ctx.fill(x1, y1 + i, x2, y1 + i + 1, Theme.mix(top, bottom, (float) i / h));
        }
    }

    /** Полоска-переключатель. p = 0..1 — анимированное положение. */
    public static void toggle(DrawContext ctx, int x, int y, boolean on, int accent) {
        toggle(ctx, x, y, on ? 1f : 0f, accent);
    }

    public static void toggle(DrawContext ctx, int x, int y, float p, int accent) {
        int w = 20, h = 11;
        p = Math.max(0f, Math.min(1f, p));
        round(ctx, x, y, x + w, y + h, 5, Theme.mix(Theme.border(), accent, p));
        int knobX = x + 1 + Math.round((w - 11) * p);
        round(ctx, knobX, y + 1, knobX + 9, y + h - 1, 4,
                Theme.mix(Theme.mix(Theme.textDim(), Theme.bg(), 0.35f), 0xFFFFFFFF, p));
    }

    /** Обводка «уголками» + лёгкая заливка — для сундуков и ящиков. */
    public static void corners(DrawContext ctx, int x1, int y1, int x2, int y2, int color, boolean fill) {
        int w = x2 - x1, h = y2 - y1;
        if (w < 2 || h < 2) return;
        if (fill) ctx.fill(x1, y1, x2, y2, Theme.alpha(color, 26));
        int cw = Math.max(2, Math.min(w / 3, 10));
        int ch = Math.max(2, Math.min(h / 3, 10));
        int t = w > 26 ? 2 : 1;
        int soft = Theme.alpha(color, 70);
        ctx.fill(x1, y1, x2, y1 + 1, soft);
        ctx.fill(x1, y2 - 1, x2, y2, soft);
        ctx.fill(x1, y1, x1 + 1, y2, soft);
        ctx.fill(x2 - 1, y1, x2, y2, soft);
        ctx.fill(x1, y1, x1 + cw, y1 + t, color);
        ctx.fill(x1, y1, x1 + t, y1 + ch, color);
        ctx.fill(x2 - cw, y1, x2, y1 + t, color);
        ctx.fill(x2 - t, y1, x2, y1 + ch, color);
        ctx.fill(x1, y2 - t, x1 + cw, y2, color);
        ctx.fill(x1, y2 - ch, x1 + t, y2, color);
        ctx.fill(x2 - cw, y2 - t, x2, y2, color);
        ctx.fill(x2 - t, y2 - ch, x2, y2, color);
    }

    /** Трассер одной линией: поворот матрицы + один прямоугольник. */
    public static void tracer(DrawContext ctx, int x1, int y1, int x2, int y2, int color, int thickness) {
        float dx = x2 - x1, dy = y2 - y1;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 2f || len > 6000f) return;
        int t = Math.max(1, thickness);
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate((float) x1, (float) y1);
        m.rotate((float) Math.atan2(dy, dx));
        ctx.fill(0, -t / 2, (int) len, -t / 2 + t, color);
        m.popMatrix();
    }

    /** Полоса прогресса/слайдера. */
    public static void slider(DrawContext ctx, int x, int y, int w, double percent, int accent, boolean hot) {
        round(ctx, x, y, x + w, y + 4, 2, Theme.border());
        int fill = (int) (w * Math.max(0, Math.min(1, percent)));
        if (fill > 0) round(ctx, x, y, x + fill, y + 4, 2, accent);
        int kx = x + Math.max(0, Math.min(w - 6, fill - 3));
        round(ctx, kx, y - 2, kx + 7, y + 6, 3, hot ? 0xFFFFFFFF : accent);
    }
}
