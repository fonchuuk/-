package ru.duo.aura.core;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;

/** Общая логика фарм-модулей: найти подходящий блок рядом и ломать его. */
public class BlockBreaker {

    /** Список подходящих блоков в радиусе, ближние первыми. */
    public static List<BlockPos> find(MinecraftClient mc, int radius, int vertical,
                                      Predicate<BlockPos> match, double maxDist) {
        List<BlockPos> out = new ArrayList<>();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) return out;

        BlockPos origin = p.getBlockPos();
        Vec3d eye = p.getEyePos();

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                for (int dy = -vertical; dy <= vertical; dy++) {
                    BlockPos pos = origin.add(dx, dy, dz);
                    if (eye.distanceTo(Vec3d.ofCenter(pos)) > maxDist) continue;
                    if (!match.test(pos)) continue;
                    out.add(pos);
                }
            }
        }
        out.sort(Comparator.comparingDouble(pos -> eye.squaredDistanceTo(Vec3d.ofCenter(pos))));
        return out;
    }

    /** Один тик ломания блока. */
    public static void breakBlock(MinecraftClient mc, BlockPos pos, boolean rotate) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return;

        if (rotate) lookAtBlock(p, pos);

        Direction side = bestSide(p, pos);
        mc.interactionManager.updateBlockBreakingProgress(pos, side);
        p.swingHand(Hand.MAIN_HAND);
    }

    private static Direction bestSide(ClientPlayerEntity p, BlockPos pos) {
        Vec3d eye = p.getEyePos();
        Vec3d c = Vec3d.ofCenter(pos);
        if (eye.y > c.y + 0.5) return Direction.UP;
        if (eye.y < c.y - 0.5) return Direction.DOWN;
        double dx = eye.x - c.x, dz = eye.z - c.z;
        if (Math.abs(dx) > Math.abs(dz)) return dx > 0 ? Direction.EAST : Direction.WEST;
        return dz > 0 ? Direction.SOUTH : Direction.NORTH;
    }

    public static void lookAtBlock(ClientPlayerEntity p, BlockPos pos) {
        Vec3d eye = p.getEyePos();
        Vec3d to = Vec3d.ofCenter(pos);
        double dx = to.x - eye.x, dy = to.y - eye.y, dz = to.z - eye.z;
        double flat = Math.sqrt(dx * dx + dz * dz);
        p.setYaw((float) (Math.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f);
        p.setPitch((float) (-(Math.atan2(dy, flat) * (180.0 / Math.PI))));
    }
}
