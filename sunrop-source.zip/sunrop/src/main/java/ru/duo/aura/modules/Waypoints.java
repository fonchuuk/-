package ru.duo.aura.modules;

import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

import java.util.ArrayList;
import java.util.List;

/**
 * Метки на местности. «Add here» ставит метку в текущей точке,
 * «Clear» стирает все. Метки видно сквозь стены с дистанцией.
 */
public class Waypoints extends Module {

    public final Setting.Bool addHere = add(new Setting.Bool("Add here", false));
    public final Setting.Bool clear = add(new Setting.Bool("Clear all", false));
    public final Setting.Bool showDistance = add(new Setting.Bool("Distance", true));
    public final Setting.Bool deathPoint = add(new Setting.Bool("Mark death", true));
    public final Setting.Num maxDistance = add(new Setting.Num("Max distance", 512, 32, 2000, 16));

    public record Point(String name, Vec3d pos) {}

    public final List<Point> points = new ArrayList<>();
    private boolean wasAlive = true;

    public Waypoints() {
        super("Waypoints", "Метки на местности", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null) return;

        if (addHere.value) {
            addHere.value = false;
            points.add(new Point("Метка " + (points.size() + 1), p.getEntityPos()));
            p.sendMessage(Text.literal("§7[Sunrop] §aметка поставлена"), true);
        }
        if (clear.value) {
            clear.value = false;
            points.clear();
            p.sendMessage(Text.literal("§7[Sunrop] §cметки стёрты"), true);
        }
        if (deathPoint.value) {
            boolean alive = p.isAlive();
            if (wasAlive && !alive) points.add(new Point("Смерть", p.getEntityPos()));
            wasAlive = alive;
        }
    }
}
