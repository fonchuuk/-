package ru.duo.aura.modules;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.CritHelper;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

public class TriggerBot extends Module {

    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 2, 0, 20, 1));
    public final Setting.Num reactionMin = add(new Setting.Num("Reaction min (ms)", 140, 0, 600, 10));
    public final Setting.Num reactionMax = add(new Setting.Num("Reaction max (ms)", 260, 0, 900, 10));
    public final Setting.Mode weapon = add(new Setting.Mode("Weapon only", 1,
            "ANY", "SWORD", "SWORD+AXE", "ANY WEAPON"));
    public final Setting.Bool lineOfSight = add(new Setting.Bool("Line of sight", true));
    public final Setting.Num maxRange = add(new Setting.Num("Max range", 3.0, 1.0, 4.5, 0.1));
    public final Setting.Mode crits = add(new Setting.Mode("Crits", 2, "OFF", "WAIT", "JUMP"));
    public final Setting.Bool unsprint = add(new Setting.Bool("Unsprint", true));
    public final Setting.Bool cooldown = add(new Setting.Bool("Vanilla cooldown", true));
    public final Setting.Bool mobs = add(new Setting.Bool("Mobs", true));
    public final Setting.Bool animals = add(new Setting.Bool("Animals", true));
    public final Setting.Bool players = add(new Setting.Bool("Players", false));

    private int timer = 0;
    private Entity lastTarget = null;
    private long aimedSince = 0;
    private long reactionNeeded = 0;
    private final java.util.Random rnd = new java.util.Random();

    /** Цель, по которой триггер сейчас работает (для HUD и подсветки). */
    public LivingEntity current = null;
    /** 0..1 — насколько «дозрела» задержка реакции. */
    public float reactionProgress = 0f;

    public TriggerBot() {
        super("TriggerBot", "Бьёт то, на что наведён прицел", Category.SWORD, GLFW.GLFW_KEY_G);
    }

    @Override
    public String hudSuffix() {
        return crits.is("OFF") ? "" : " §7[" + crits.get() + "]";
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) return;
        if (p.isSpectator() || !p.isAlive()) return;

        if (timer > 0) { timer--; return; }

        if (!weaponOk(p)) { resetAim(); return; }

        HitResult hit = mc.crosshairTarget;
        if (hit == null || hit.getType() != HitResult.Type.ENTITY) { resetAim(); return; }

        Entity e = ((EntityHitResult) hit).getEntity();
        if (!(e instanceof LivingEntity le) || !le.isAlive()) { resetAim(); return; }
        if (!valid(le, p)) { resetAim(); return; }

        // дистанция как у обычного удара рукой
        if (p.distanceTo(le) > maxRange.value) { resetAim(); return; }

        // не бьём сквозь блоки
        if (lineOfSight.value && !p.canSee(le)) { resetAim(); return; }

        // «реакция»: прицел должен постоять на цели, как у живого игрока
        long now = System.currentTimeMillis();
        if (lastTarget != le) {
            lastTarget = le;
            aimedSince = now;
            double lo = Math.min(reactionMin.value, reactionMax.value);
            double hi = Math.max(reactionMin.value, reactionMax.value);
            reactionNeeded = (long) (lo + rnd.nextDouble() * (hi - lo));
        }
        current = le;
        reactionProgress = reactionNeeded <= 0 ? 1f
                : Math.min(1f, (now - aimedSince) / (float) reactionNeeded);
        ru.duo.aura.core.TargetTracker.set(le, "TriggerBot");
        if (now - aimedSince < reactionNeeded) return;

        if (cooldown.value && p.getAttackCooldownProgress(0.0f) < 1.0f) return;
        if (!CritHelper.prepare(p, crits.get(), unsprint.value)) return;

        mc.interactionManager.attackEntity(p, le);
        p.swingHand(Hand.MAIN_HAND);
        // лёгкий разброс паузы между ударами — ритм не строго машинный
        timer = delay.asInt() + (delay.asInt() > 0 ? rnd.nextInt(2) : 0);
    }

    private void resetAim() {
        lastTarget = null;
        current = null;
        reactionProgress = 0f;
        ru.duo.aura.core.TargetTracker.clear("TriggerBot");
    }

    @Override
    public void onDisable() {
        resetAim();
        timer = 0;
    }

    /** Проверка предмета в главной руке по выбранному режиму. */
    private boolean weaponOk(ClientPlayerEntity p) {
        var stack = p.getMainHandStack();
        if (stack.isEmpty()) return weapon.is("ANY");
        boolean sword = stack.isIn(net.minecraft.registry.tag.ItemTags.SWORDS);
        boolean axe = stack.isIn(net.minecraft.registry.tag.ItemTags.AXES);
        boolean trident = stack.isOf(net.minecraft.item.Items.TRIDENT)
                || stack.isOf(net.minecraft.item.Items.MACE);
        return switch (weapon.get()) {
            case "SWORD" -> sword;
            case "SWORD+AXE" -> sword || axe;
            case "ANY WEAPON" -> sword || axe || trident;
            default -> true;
        };
    }

    private boolean valid(LivingEntity e, ClientPlayerEntity self) {
        if (e instanceof PlayerEntity pl) {
            if (ru.duo.aura.core.ModuleManager.friendManager != null
                    && ru.duo.aura.core.ModuleManager.friendManager.isEnabled()
                    && ru.duo.aura.core.ModuleManager.friendManager.protectFromAura.value
                    && ru.duo.aura.core.Friends.is(pl.getName().getString())) return false;
            return players.value && !self.isTeammate(pl);
        }
        if (e instanceof AnimalEntity) return animals.value;
        return mobs.value;
    }
}
