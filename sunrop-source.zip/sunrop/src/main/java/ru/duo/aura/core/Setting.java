package ru.duo.aura.core;

public abstract class Setting {
    public final String name;

    protected Setting(String name) {
        this.name = name;
    }

    public abstract String serialize();

    public abstract void deserialize(String s);

    // ---------- bool ----------
    public static class Bool extends Setting {
        public boolean value;

        public Bool(String name, boolean value) {
            super(name);
            this.value = value;
        }

        public void toggle() { value = !value; }

        @Override public String serialize() { return Boolean.toString(value); }
        @Override public void deserialize(String s) { value = Boolean.parseBoolean(s); }
    }

    // ---------- number ----------
    public static class Num extends Setting {
        public double value;
        public final double min, max, step;

        public Num(String name, double value, double min, double max, double step) {
            super(name);
            this.value = value; this.min = min; this.max = max; this.step = step;
        }

        public int asInt() { return (int) Math.round(value); }

        public void setFromPercent(double p) {
            double raw = min + (max - min) * Math.max(0, Math.min(1, p));
            value = Math.round(raw / step) * step;
            value = Math.max(min, Math.min(max, value));
        }

        public double percent() { return (value - min) / (max - min); }

        public String display() {
            return step >= 1 ? String.valueOf(asInt()) : String.format("%.2f", value);
        }

        @Override public String serialize() { return Double.toString(value); }
        @Override public void deserialize(String s) {
            try { value = Double.parseDouble(s); } catch (NumberFormatException ignored) {}
        }
    }

    // ---------- mode ----------
    public static class Mode extends Setting {
        public final String[] modes;
        public int index;

        public Mode(String name, int index, String... modes) {
            super(name);
            this.modes = modes;
            this.index = index;
        }

        public String get() { return modes[index]; }
        public boolean is(String s) { return modes[index].equalsIgnoreCase(s); }
        public void next() { index = (index + 1) % modes.length; }

        @Override public String serialize() { return get(); }
        @Override public void deserialize(String s) {
            for (int i = 0; i < modes.length; i++) if (modes[i].equalsIgnoreCase(s)) index = i;
        }
    }
}
