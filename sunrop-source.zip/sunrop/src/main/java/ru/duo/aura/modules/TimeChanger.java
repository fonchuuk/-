package ru.duo.aura.modules;

import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/** Своё время суток (только у тебя на клиенте). */
public class TimeChanger extends Module {

    public final Setting.Mode preset = add(new Setting.Mode("Preset", 0, "DAY", "NOON", "SUNSET", "NIGHT", "CUSTOM"));
    public final Setting.Num custom = add(new Setting.Num("Custom time", 1000, 0, 24000, 100));

    public TimeChanger() {
        super("TimeChanger", "Меняет время суток на клиенте", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onTick() {
        if (mc.world == null) return;
        long t = switch (preset.get()) {
            case "DAY" -> 1000L;
            case "NOON" -> 6000L;
            case "SUNSET" -> 12500L;
            case "NIGHT" -> 18000L;
            default -> (long) custom.value;
        };
        mc.world.setTime(mc.world.getTime(), t, false);
    }

    @Override
    public String hudSuffix() { return " §7[" + preset.get() + "]"; }
}
