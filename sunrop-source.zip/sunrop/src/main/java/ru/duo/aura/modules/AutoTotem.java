package ru.duo.aura.modules;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.Module;
import ru.duo.aura.core.Setting;

/** Автоматически кладёт тотем бессмертия во вторую руку, когда мало HP. */
public class AutoTotem extends Module {

    public final Setting.Num health = add(new Setting.Num("Health", 12, 1, 20, 1));
    public final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 2, 0, 20, 1));

    private int timer = 0;

    public AutoTotem() {
        super("AutoTotem", "Ставит тотем в левую руку при низком HP", Category.CRYSTAL, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null) return;

        if (timer > 0) { timer--; return; }
        if (p.getHealth() + p.getAbsorptionAmount() > health.value) return;
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;

        int slot = -1;
        for (int i = 0; i < p.getInventory().size(); i++) {
            if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) { slot = i; break; }
        }
        if (slot == -1) return;

        // инвентарные слоты: 0-8 хотбар -> 36-44 в screen handler
        int screenSlot = slot < 9 ? slot + 36 : slot;
        mc.interactionManager.clickSlot(p.currentScreenHandler.syncId, screenSlot, 40,
                SlotActionType.SWAP, p);
        timer = delay.asInt();
    }
}
