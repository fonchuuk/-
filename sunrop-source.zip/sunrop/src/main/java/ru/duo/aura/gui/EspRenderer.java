package ru.duo.aura.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import ru.duo.aura.core.ModuleManager;
import ru.duo.aura.core.Theme;
import ru.duo.aura.modules.Esp;
import ru.duo.aura.modules.SeeInvis;

import java.util.ArrayList;
import java.util.List;

/**
 * ESP через экранную проекцию. Список существ пересобирается не каждый кадр,
 * а раз в несколько тиков — отрисовка остаётся дешёвой даже в толпе мобов.
 */
public class EspRenderer {

    private static final List<Entry> CACHE = new ArrayList<>();
    private static long lastScan = 0;
    private static int errors = 0;

    private record Entry(Entity entity, boolean invisible) {}

    public static void render(DrawContext ctx) {
        Esp esp = ModuleManager.esp;
        SeeInvis invis = ModuleManager.seeInvis;
        boolean espOn = esp != null && esp.isEnabled();
        boolean invisOn = invis != null && invis.isEnabled();
        if (!espOn && !invisOn) { CACHE.clear(); return; }

        try {
            draw(ctx, esp, invis, espOn, invisOn);
        } catch (Throwable t) {
            errors++;
            System.err.println("[Sunrop] ESP ошибка: " + t);
            if (errors >= 5) {
                if (esp != null) esp.setEnabled(false);
                errors = 0;
                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc.player != null) {
                    mc.player.sendMessage(Text.literal("§7[Sunrop] §cESP выключен из-за ошибки: " + t), false);
                }
            }
        }
    }

    private static void draw(DrawContext ctx, Esp esp, SeeInvis invis, boolean espOn, boolean invisOn) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        Camera camera = mc.gameRenderer.getCamera();
        if (camera == null || !camera.isReady()) return;

        Projector proj = Projector.of(camera, ctx.getScaledWindowWidth(), ctx.getScaledWindowHeight());
        if (proj == null) return;

        rescan(mc, esp, invis, espOn, invisOn);
        if (CACHE.isEmpty()) return;

        float tick = mc.getRenderTickCounter().getTickProgress(false);
        Entity target = (espOn && ModuleManager.killAura != null) ? ModuleManager.killAura.current : null;
        boolean staticBox = !espOn || esp.boxMode.is("STATIC");
        int limit = espOn ? esp.maxEntities.asInt() : 64;
        int drawn = 0;
        int tracers = 0;

        for (Entry entry : CACHE) {
            if (drawn >= limit) break;
            Entity e = entry.entity();
            if (e.isRemoved()) continue;

            boolean viaInvis = entry.invisible();
            boolean drawBoxes = viaInvis ? invis.boxes.value : esp.boxes.value;
            boolean drawNames = viaInvis ? invis.names.value : esp.names.value;

            // позиция через getLerpedPos: работает и для невидимых,
            // которых игра вообще не рендерит
            Vec3d pos = e.getLerpedPos(tick);
            float w = e.getWidth();
            float h = e.getHeight();

            float[] rect = staticBox
                    ? proj.staticBox(pos, w, h)
                    : proj.cornerBox(pos, w, h);
            if (rect == null) continue;

            int x1 = (int) rect[0], y1 = (int) rect[1], x2 = (int) rect[2], y2 = (int) rect[3];
            if (x2 - x1 < 1 || y2 - y1 < 2) continue;

            int color = viaInvis ? 0xFFC060FF : colorFor(e, e == target);
            drawn++;

            if (drawBoxes) {
                outline(ctx, x1, y1, x2, y2, color);
                if (espOn && e == target && esp.targetGlow.value) {
                    outline(ctx, x1 - 1, y1 - 1, x2 + 1, y2 + 1, 0xFFFF3030);
                }
            }

            if (espOn && !viaInvis && esp.healthBar.value && e instanceof LivingEntity le) {
                float f = Math.max(0f, Math.min(1f, le.getHealth() / Math.max(1f, le.getMaxHealth())));
                int bx = x1 - 4;
                ctx.fill(bx, y1, bx + 2, y2, 0xAA000000);
                int filled = (int) ((y2 - y1) * f);
                int hc = 0xFF000000 | ((int) (255 * (1 - f)) << 16) | ((int) (255 * f) << 8);
                ctx.fill(bx, y2 - filled, bx + 2, y2, hc);
            }

            if (drawNames) {
                String label = e.getName().getString();
                if (e instanceof LivingEntity le) label += " §c" + (int) Math.ceil(le.getHealth());
                int tw = mc.textRenderer.getWidth(label);
                int tx = (x1 + x2) / 2 - tw / 2;
                ctx.fill(tx - 2, y1 - 11, tx + tw + 2, y1 - 1, 0x99000000);
                ctx.drawText(mc.textRenderer, label, tx, y1 - 10, 0xFFFFFFFF, false);
            }

            if (espOn && !viaInvis && esp.tracers.value && tracers < esp.tracerLimit.asInt()) {
                tracers++;
                Draw.tracer(ctx, ctx.getScaledWindowWidth() / 2, ctx.getScaledWindowHeight(),
                        (x1 + x2) / 2, y2, color, esp.tracerWidth.asInt());
            }
        }
    }

    /** Пересобираем список целей раз в 150 мс, а не каждый кадр. */
    private static void rescan(MinecraftClient mc, Esp esp, SeeInvis invis,
                               boolean espOn, boolean invisOn) {
        long now = System.currentTimeMillis();
        if (now - lastScan < 150 && !CACHE.isEmpty()) return;
        lastScan = now;
        CACHE.clear();

        double espRangeSq = espOn ? esp.range.value * esp.range.value : 0;
        double invisRangeSq = invisOn ? invis.range.value * invis.range.value : 0;
        final Vec3d self = mc.player.getEntityPos();
        int cap = (espOn ? esp.maxEntities.asInt() : 64) * 2;

        // запрашиваем только то, что в радиусе: игра возьмёт нужные секции чанков
        // вместо полного обхода всех сущностей мира
        double r = Math.max(espOn ? esp.range.value : 0, invisOn ? invis.range.value : 0);
        net.minecraft.util.math.Box box = new net.minecraft.util.math.Box(
                self.x - r, self.y - r, self.z - r, self.x + r, self.y + r, self.z + r);
        for (Entity e : mc.world.getOtherEntities(mc.player, box)) {
            if (e.isRemoved()) continue;
            double dSq = e.getEntityPos().squaredDistanceTo(self);

            boolean viaInvis = invisOn && dSq <= invisRangeSq && invis.shows(e) && invis.isRevealed(e);
            boolean viaEsp = espOn && dSq <= espRangeSq && wanted(esp, e);
            if (!viaEsp && !viaInvis) continue;

            CACHE.add(new Entry(e, viaInvis));
            if (CACHE.size() >= cap) break;
        }
        // ближние первыми — трассеры и лимит достаются тем, кто реально рядом
        CACHE.sort(java.util.Comparator.comparingDouble(
                e -> e.entity().squaredDistanceTo(self)));
    }

    private static void outline(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        ctx.fill(x1, y1, x2, y1 + 1, color);
        ctx.fill(x1, y2 - 1, x2, y2, color);
        ctx.fill(x1, y1, x1 + 1, y2, color);
        ctx.fill(x2 - 1, y1, x2, y2, color);
    }

    private static void line(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        int steps = Math.max(Math.abs(x2 - x1), Math.abs(y2 - y1));
        if (steps <= 0 || steps > 2000) return;
        int stride = Math.max(2, steps / 160);
        for (int i = 0; i <= steps; i += stride) {
            int x = x1 + (x2 - x1) * i / steps;
            int y = y1 + (y2 - y1) * i / steps;
            ctx.fill(x, y, x + 1, y + 1, color);
        }
    }

    private static boolean wanted(Esp esp, Entity e) {
        if (e instanceof ItemEntity) return esp.items.value;
        if (e instanceof PlayerEntity) return esp.players.value;
        if (e instanceof Monster) return esp.mobs.value;
        if (e instanceof AnimalEntity) return esp.animals.value;
        return false;
    }

    private static int colorFor(Entity e, boolean isTarget) {
        if (e instanceof PlayerEntity && ModuleManager.friendManager != null
                && ModuleManager.friendManager.isEnabled()
                && ModuleManager.friendManager.colorInEsp.value
                && ru.duo.aura.core.Friends.is(e.getName().getString())) return 0xFF40FF80;
        if (isTarget) return 0xFFFF3030;
        if (e instanceof ItemEntity) return 0xFFFFD040;
        if (e instanceof PlayerEntity) return Theme.accent();
        if (e instanceof Monster) return 0xFFFF6060;
        return 0xFF80FF80;
    }

    /** Мир → экран через базис камеры (yaw/pitch) и тангенсы половин FOV. */
    public static class Projector {
        private final Vec3d camPos, forward, right, up;
        private final double tanX, tanY;
        private final int width, height;

        private Projector(Vec3d camPos, Vec3d forward, Vec3d right, Vec3d up,
                          double tanX, double tanY, int width, int height) {
            this.camPos = camPos; this.forward = forward; this.right = right; this.up = up;
            this.tanX = tanX; this.tanY = tanY; this.width = width; this.height = height;
        }

        public static Projector of(Camera camera, int width, int height) {
            MinecraftClient mc = MinecraftClient.getInstance();
            Vec3d forward = Vec3d.fromPolar(camera.getPitch(), camera.getYaw());
            Vec3d right = Vec3d.fromPolar(0.0f, camera.getYaw() + 90.0f);
            Vec3d up = right.crossProduct(forward);

            double fovDeg = mc.options.getFov().getValue();
            if (fovDeg <= 1 || fovDeg >= 179) fovDeg = 70;
            double tanY = Math.tan(Math.toRadians(fovDeg) / 2.0);
            double aspect = (double) mc.getWindow().getFramebufferWidth()
                    / Math.max(1, mc.getWindow().getFramebufferHeight());

            return new Projector(camera.getCameraPos(), forward, right, up,
                    tanY * aspect, tanY, width, height);
        }

        public float[] project(double wx, double wy, double wz) {
            double dx = wx - camPos.x, dy = wy - camPos.y, dz = wz - camPos.z;
            double depth = dx * forward.x + dy * forward.y + dz * forward.z;
            if (depth <= 0.05) return null;

            double x = (dx * right.x + dy * right.y + dz * right.z) / depth / tanX;
            double y = (dx * up.x + dy * up.y + dz * up.z) / depth / tanY;
            return new float[]{
                    (float) ((0.5 + 0.5 * x) * width),
                    (float) ((0.5 - 0.5 * y) * height)};
        }

        /** Ровная рамка по центру существа — не пляшет при повороте камеры. */
        public float[] staticBox(Vec3d pos, float w, float h) {
            float[] bottom = project(pos.x, pos.y, pos.z);
            float[] top = project(pos.x, pos.y + h, pos.z);
            if (bottom == null || top == null) return null;

            float ph = Math.abs(bottom[1] - top[1]);
            if (ph < 2) return null;
            float pw = (float) (ph * (w / Math.max(0.1f, h)));

            float cx = (bottom[0] + top[0]) * 0.5f;
            float y1 = Math.min(top[1], bottom[1]);
            float y2 = Math.max(top[1], bottom[1]);
            float[] r = {cx - pw / 2f, y1, cx + pw / 2f, y2};
            if (r[2] < 0 || r[3] < 0 || r[0] > width || r[1] > height) return null;
            return r;
        }

        /** Рамка по 8 углам хитбокса. */
        public float[] cornerBox(Vec3d pos, float w, float h) {
            double hw = w / 2.0;
            double minX = pos.x - hw, maxX = pos.x + hw;
            double minZ = pos.z - hw, maxZ = pos.z + hw;
            double minY = pos.y, maxY = pos.y + h;

            float x1 = Float.MAX_VALUE, y1 = Float.MAX_VALUE;
            float x2 = -Float.MAX_VALUE, y2 = -Float.MAX_VALUE;

            for (int i = 0; i < 8; i++) {
                double cx = (i & 1) == 0 ? minX : maxX;
                double cy = (i & 2) == 0 ? minY : maxY;
                double cz = (i & 4) == 0 ? minZ : maxZ;
                float[] s = project(cx, cy, cz);
                if (s == null) return null;
                x1 = Math.min(x1, s[0]); x2 = Math.max(x2, s[0]);
                y1 = Math.min(y1, s[1]); y2 = Math.max(y2, s[1]);
            }
            if (x2 < 0 || y2 < 0 || x1 > width || y1 > height) return null;
            return new float[]{x1, y1, x2, y2};
        }
    }
}
