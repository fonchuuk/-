package ru.duo.aura.modules;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.item.ShovelItem;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.glfw.GLFW;
import ru.duo.aura.core.Category;
import ru.duo.aura.core.FarmModule;
import ru.duo.aura.core.Setting;

/** Копает песок, красный песок и гравий, сам подходя к ним. */
public class SandFarmer extends FarmModule {

    public final Setting.Bool sand = add(new Setting.Bool("Sand", true));
    public final Setting.Bool redSand = add(new Setting.Bool("Red sand", true));
    public final Setting.Bool gravel = add(new Setting.Bool("Gravel", true));
    public final Setting.Bool autoTool = add(new Setting.Bool("Auto shovel", true));

    public SandFarmer() {
        super("SandFarmer", "Копает песок и гравий вокруг", Category.FARM, GLFW.GLFW_KEY_UNKNOWN);
        radius.value = 8;
        vertical.value = 4;
    }

    @Override
    protected boolean matches(BlockPos pos) {
        if (mc.world == null) return false;
        BlockState st = mc.world.getBlockState(pos);
        if (sand.value && st.isOf(Blocks.SAND)) return true;
        if (redSand.value && st.isOf(Blocks.RED_SAND)) return true;
        return gravel.value && st.isOf(Blocks.GRAVEL);
    }

    @Override
    protected void beforeBreak(BlockPos pos) {
        if (!autoTool.value || mc.player == null) return;
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() instanceof ShovelItem) {
                if (mc.player.getInventory().getSelectedSlot() != i) {
                    mc.player.getInventory().setSelectedSlot(i);
                }
                return;
            }
        }
    }
}
